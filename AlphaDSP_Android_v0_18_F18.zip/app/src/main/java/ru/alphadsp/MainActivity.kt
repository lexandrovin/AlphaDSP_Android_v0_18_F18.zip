package ru.alphadsp
import android.Manifest
import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
class MainActivity : ComponentActivity() {
lateinit var wv: WebView
var ar: AudioRecord? = null; var recording = false; val buf = ByteArrayOutputStream(); var wavPath = ""
val SR = 44100
val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? -> if (u != null) load { val w = File(cacheDir, "in.wav"); Pair(w, Converter.toWav(this, u, w)) } }
val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) startRec() else js("alert('Нужно разрешение на микрофон')") }
fun js(s: String) = runOnUiThread { wv.evaluateJavascript(s, null) }
fun py(kind: String, a: Double, b: Double, win: Double, hop: Double, ceil: Double, nfm: Int): String = Python.getInstance().getModule("viz").callAttr("run", kind, wavPath, a, b, win, hop, ceil, nfm).toString()
inner class Br {
@JavascriptInterface fun rec() { runOnUiThread { if (recording) stopRec() else askMic.launch(Manifest.permission.RECORD_AUDIO) } }
@JavascriptInterface fun pick() { runOnUiThread { pickFile.launch("audio/*") } }
@JavascriptInterface fun analyze(kind: String, a: Double, b: Double, win: Double, hop: Double, ceil: Double, nfm: Int) { Thread { val r = try { py(kind, a, b, win, hop, ceil, nfm) } catch (e: Throwable) { JSONObject().put("err", e.message).toString() }; js("onRes('$kind',$r)") }.start() }
}
@SuppressLint("SetJavaScriptEnabled")
override fun onCreate(s: Bundle?) {
super.onCreate(s)
if (!Python.isStarted()) Python.start(AndroidPlatform(this))
wv = WebView(this); wv.settings.javaScriptEnabled = true; wv.settings.domStorageEnabled = true; wv.addJavascriptInterface(Br(), "Android"); wv.loadUrl("file:///android_asset/index.html"); setContentView(wv)
}
fun load(job: () -> Pair<File, Info>) { js("document.getElementById('busy').style.display='block'"); Thread { try { val (w, info) = job(); wavPath = w.absolutePath; val j = py("info", 0.0, 0.0, 0.0, 0.0, 0.0, 0); js("onLoaded($j, ${JSONArray(info.warnings())})") } catch (e: Throwable) { js("document.getElementById('busy').style.display='none';alert(${JSONObject.quote("Ошибка: " + e.message)})") } }.start() }
fun startRec() {
val min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
var a = AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4)
if (a.state != AudioRecord.STATE_INITIALIZED) a = AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4)
ar = a; buf.reset(); recording = true; js("setRec(true)"); a.startRecording()
Thread { val b = ByteArray(min); while (recording) { val n = a.read(b, 0, b.size); if (n > 0) synchronized(buf) { buf.write(b, 0, n) } } }.start()
}
fun stopRec() {
recording = false; js("setRec(false)"); ar?.stop(); ar?.release(); Thread.sleep(150)
load { val bb = ByteBuffer.wrap(synchronized(buf) { buf.toByteArray() }).order(ByteOrder.LITTLE_ENDIAN); val s = ShortArray(bb.remaining() / 2) { bb.getShort() }; val w = File(cacheDir, "rec.wav"); Converter.writeWav(w, s, SR); Pair(w, Info(SR, 16, false, s.size.toDouble() / SR)) }
}
}
