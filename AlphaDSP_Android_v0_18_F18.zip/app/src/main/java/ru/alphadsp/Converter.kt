package ru.alphadsp
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
data class Info(val sr: Int, val bits: Int?, val lossy: Boolean, val sec: Double) {
fun warnings(): List<String> {
val w = ArrayList<String>()
if (sr < 44100) w.add("Частота $sr Гц ниже 44100 Гц: будут доступны форманты только до F${sr / 2000}. Звук не растягивается до 44,1 кГц, потому что это не вернёт потерянные частоты.")
if (bits != null && bits < 16) w.add("Разрядность $bits бит ниже 16: точность будет хуже.")
if (lossy) w.add("Формат со сжатием (mp3, aac, ogg и др.): сжатие могло срезать высокие частоты, F9–F18 ненадёжны. Лучше записать WAV 44,1 кГц, 16 бит.")
return w
}
}
object Converter {
fun writeWav(f: File, s: ShortArray, sr: Int) {
val b = ByteBuffer.allocate(44 + s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
b.put("RIFF".toByteArray()).putInt(36 + s.size * 2).put("WAVEfmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(sr).putInt(sr * 2).putShort(2).putShort(16).put("data".toByteArray()).putInt(s.size * 2)
for (v in s) b.putShort(v)
f.writeBytes(b.array())
}
fun toWav(ctx: Context, uri: Uri, out: File): Info {
val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
val ti = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") } ?: throw Exception("В файле нет звука")
ex.selectTrack(ti)
val f = ex.getTrackFormat(ti); val mime = f.getString(MediaFormat.KEY_MIME)!!
var sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
var enc = 2
val srcBits = if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) when (f.getInteger(MediaFormat.KEY_PCM_ENCODING)) { 3 -> 8; 2 -> 16; 4 -> 32; else -> null } else null
val lossy = !(mime == "audio/raw" || mime == "audio/flac" || mime == "audio/alac")
val dec = MediaCodec.createDecoderByType(mime); dec.configure(f, null, null, 0); dec.start()
val bi = MediaCodec.BufferInfo(); var inDone = false; var outDone = false; val pcm = ByteArrayOutputStream()
while (!outDone) {
if (!inDone) { val i = dec.dequeueInputBuffer(10000); if (i >= 0) { val b = dec.getInputBuffer(i)!!; val n = ex.readSampleData(b, 0); if (n < 0) { dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true } else { dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() } } }
val o = dec.dequeueOutputBuffer(bi, 10000)
if (o >= 0) { val b = dec.getOutputBuffer(o)!!; val a = ByteArray(bi.size); b.position(bi.offset); b.get(a); pcm.write(a); dec.releaseOutputBuffer(o, false); if (bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true }
else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { val nf = dec.outputFormat; sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT); if (nf.containsKey(MediaFormat.KEY_PCM_ENCODING)) enc = nf.getInteger(MediaFormat.KEY_PCM_ENCODING) }
}
dec.stop(); dec.release(); ex.release()
val raw = ByteBuffer.wrap(pcm.toByteArray()).order(ByteOrder.LITTLE_ENDIAN)
val n = raw.remaining() / (if (enc == 4) 4 else 2) / ch
val m = ShortArray(n)
for (i in 0 until n) { var s = 0.0; for (c in 0 until ch) s += if (enc == 4) raw.getFloat() * 32767.0 else raw.getShort().toDouble(); m[i] = (s / ch).coerceIn(-32768.0, 32767.0).toInt().toShort() }
writeWav(out, m, sr)
return Info(sr, srcBits, lossy, n.toDouble() / sr)
}
}
