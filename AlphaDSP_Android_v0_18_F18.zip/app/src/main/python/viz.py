import numpy as np, base64, json, os
from math import gcd
from scipy.io import wavfile
from scipy.signal import resample_poly
from alpha_dsp.core.f0 import HybridF0
from alpha_dsp.core.formants_high import _frame, _lpc
_K = {}
def _load(p, k): sr, d = wavfile.read(p); d = d.astype(np.float64) / (32768.0 if d.dtype == np.int16 else 1.0); x = d.mean(1) if d.ndim > 1 else d; _K.clear(); _K.update(k=k, x=x, sr=int(sr), pk=max(1e-9, float(np.abs(x).max())), f0=None)
def _x(p):
 s = os.stat(p); k = (p, s.st_mtime_ns, s.st_size)
 if _K.get("k") != k: _load(p, k)
 return _K["x"], _K["sr"]
def _ab(x, sr, a, b): return max(0.0, a), min(b, 1000.0 * len(x) / sr)
def _pre(x, sr, hz): return np.r_[x[0], x[1:] - np.exp(-2 * np.pi * hz / sr) * x[:-1]]
def _win(x, sr, c, w): xp = np.pad(x, (w, w)); return xp[c.astype(int)[:, None] + np.arange(w)[None, :] + w - w // 2]
def _nf(n, w): return int(max(2, min(n, (w // 3 - 2) // 2)))
def _f0(p): x, sr = _x(p); g = gcd(16000, sr); y = resample_poly(x, 16000 // g, sr // g); r = HybridF0(sr=16000, fmax=600.0, prefilter="lp", gate_db=-18.0, voicing_threshold=0.5).estimate(y); _K["f0"] = _K["f0"] or (np.asarray(r.times) * 1000.0, np.nan_to_num(np.asarray(r.f0), nan=0.0)); return _K["f0"]
def wave(p, a, b, nb=1400):
 x, sr = _x(p); a, b = _ab(x, sr, a, b); i0 = int(a * sr / 1000); s = x[i0:max(i0 + 2, int(b * sr / 1000))] / _K["pk"]; n = len(s) // nb
 if n < 2: return {"a": a, "b": b, "s": np.round(s, 3).tolist()}
 q = s[:n * nb].reshape(nb, n); return {"a": a, "b": b, "mm": np.round(np.c_[q.min(1), q.max(1)], 3).ravel().tolist()}
def info(p): x, sr = _x(p); ms = 1000.0 * len(x) / sr; return {"sr": sr, "ms": ms, "w": wave(p, 0, ms)}
def loud(p, a, b, nb=1200):
 x, sr = _x(p); a, b = _ab(x, sr, a, b); s = x[int(a * sr / 1000):int(b * sr / 1000)]; n = max(1, len(s) // nb); m = len(s) // n; r = np.sqrt((s[:m * n].reshape(m, n) ** 2).mean(1)) if m > 0 else np.zeros(1)
 return {"a": a, "b": b, "db": np.round(np.maximum(20 * np.log10(r / _K["pk"] + 1e-9), -80), 1).tolist()}
def spec(p, a, b, win, hop, fmax):
 x, sr = _x(p); a, b = _ab(x, sr, a, b); x = np.r_[x[0], x[1:] - 0.97 * x[:-1]]; nc = int(min(1400, max(2, (b - a) / hop))); c = (a + (b - a) * (np.arange(nc) + 0.5) / nc) * sr / 1000.0; w = max(16, int(win * sr / 1000)); nf = 1 << int(np.ceil(np.log2(w * 2)))
 S = np.abs(np.fft.rfft(_win(x, sr, c, w) * np.hanning(w), nf, axis=1)); k = int(min(S.shape[1] - 1, fmax * nf / sr)) + 1; S = 20 * np.log10(S[:, :k] + 1e-9); S = S[:, ::max(1, k // 256)]; q = np.clip((S - (S.max() - 80)) / 80, 0, 1) * 255
 return {"nc": nc, "nr": int(q.shape[1]), "hop": (b - a) / nc, "a": a, "b": b, "fmax": (k - 1) * sr / nf, "data": base64.b64encode(q.astype(np.uint8).tobytes()).decode()}
def _fb(w, sr, n, ok): f, bw = _frame(w, sr, n, 1000.0) if ok else (np.array([]), np.array([])); z = np.full(n - len(f), np.nan); return np.r_[f, z], np.r_[bw, z]
def fmt(p, a, b, win, hop, nfm):
 x, sr = _x(p); a, b = _ab(x, sr, a, b); x = _pre(x, sr, 50.0); hop = max(hop, (b - a) / 6000.0, win / 16.0); w = max(32, int(win * sr / 1000)); nfm = _nf(min(int(nfm), sr // 2000), w); c = np.arange(a, b, hop) * sr / 1000.0; W = _win(x, sr, c, w); r = np.sqrt((W ** 2).mean(1)); ok = r > max(1e-6, 0.05 * r.max())
 R = [_fb(W[i], sr, nfm, ok[i]) for i in range(len(W))]; M = np.array([q[0] for q in R], dtype=np.float32); B = np.nan_to_num(np.minimum(np.array([q[1] for q in R]), 65000), nan=65000).astype(np.uint16)
 return {"n": int(len(M)), "nfm": nfm, "hop": hop, "a": a, "b": b, "data": base64.b64encode(M.tobytes()).decode(), "bw": base64.b64encode(B.tobytes()).decode()}
def f0(p, a, b): t, f = _f0(p); dt = float(np.median(np.diff(t))) if len(t) > 1 else 0.0; m = (t >= a - 2 * dt) & (t <= b + 2 * dt); return {"t": np.round(t[m], 2).tolist(), "f": np.round(f[m], 1).tolist(), "a": a, "b": b, "dt": dt}
def slice_(p, t, win, ceil, nfm):
 x, sr = _x(p); xp = _pre(x, sr, 50.0); w = max(16, int(win * sr / 1000)); c = np.array([t * sr / 1000.0]); raw = _win(x, sr, c, w)[0] * np.hanning(w); seg = _win(xp, sr, c, w)[0]; nfm = _nf(min(int(nfm), sr // 2000), w)
 nf = max(4096, 1 << int(np.ceil(np.log2(w * 4)))); S = np.abs(np.fft.rfft(raw, nf)); k = int(min(len(S) - 1, ceil * nf / sr)) + 1; db = 20 * np.log10(S[:k] + 1e-9); a_ = _lpc(seg * np.hanning(w), 2 * nfm + 2)
 env = np.zeros(k) if a_ is None else -20 * np.log10(np.abs(np.fft.rfft(a_, nf))[:k] + 1e-9); env = env + (np.percentile(db, 90) - np.percentile(env, 90)); st = max(1, k // 1500); m = k // st * st; db = db[:m].reshape(-1, st).max(1); env = env[:m].reshape(-1, st).mean(1)
 f, bw = _frame(seg, sr, nfm, 1000.0); tt, ff = _f0(p); i = int(np.argmin(np.abs(tt - t))); f0v = float(ff[i]) if abs(tt[i] - t) < 15 else 0.0
 return {"t": t, "ta": t - 500.0 * w / sr, "tb": t + 500.0 * w / sr, "df": sr / nf * st, "db": np.round(db, 1).tolist(), "env": np.round(env, 1).tolist(), "f": np.round(f, 1).tolist(), "bw": np.round(bw, 0).tolist(), "f0": f0v, "win": win, "nfm": nfm}
def run(kind, p, a, b, win, hop, ceil, nfm):
 k = kind.split("#")[0]
 try:
  if k == "info": return json.dumps(info(p))
  if k == "wave": return json.dumps(wave(p, a, b))
  if k == "loud": return json.dumps(loud(p, a, b))
  if k == "spec": return json.dumps(spec(p, a, b, win, hop, ceil))
  if k in ("fmt", "fmt2"): return json.dumps(fmt(p, a, b, win, hop, nfm))
  if k == "f0": return json.dumps(f0(p, a, b))
  if k.startswith("slice"): return json.dumps(slice_(p, a, win, ceil, nfm))
  import app_run; return json.dumps(app_run.run(p))
 except Exception as e: return json.dumps({"err": str(e)})
