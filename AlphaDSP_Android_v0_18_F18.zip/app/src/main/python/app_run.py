from alpha_dsp.engine import AlphaDSP
def run(p): s = AlphaDSP().analyze(p)["summary"]; return "\n".join(f"{k}: {round(v, 4) if isinstance(v, float) else v}" for k, v in s.items() if not isinstance(v, (list, dict)))
