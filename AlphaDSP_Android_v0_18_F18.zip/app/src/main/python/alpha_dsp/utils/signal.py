"""
AlphaDSP · базовые операции над сигналом
"""

from __future__ import annotations

import numpy as np
from scipy.signal import butter, filtfilt, medfilt, find_peaks
from scipy.interpolate import interp1d


def preemphasis(x: np.ndarray, coef: float = 0.97) -> np.ndarray:
    """Стандартный pre-emphasis: y[n] = x[n] - coef * x[n-1]"""
    y = np.empty_like(x)
    y[0] = x[0]
    y[1:] = x[1:] - coef * x[:-1]
    return y


def frame_signal(
    x: np.ndarray,
    frame_len: int,
    hop: int,
    window: str = "hann",
) -> np.ndarray:
    """
    Разбиение на кадры с окном.
    Возвращает (n_frames, frame_len).
    """
    n = len(x)
    n_frames = 1 + max(0, (n - frame_len) // hop)
    frames = np.zeros((n_frames, frame_len), dtype=np.float64)
    win = np.hanning(frame_len) if window == "hann" else np.ones(frame_len)
    for i in range(n_frames):
        start = i * hop
        end = start + frame_len
        chunk = x[start:end]
        if len(chunk) < frame_len:
            chunk = np.pad(chunk, (0, frame_len - len(chunk)))
        frames[i] = chunk * win
    return frames


def rms_energy(x: np.ndarray, frame_len: int, hop: int) -> np.ndarray:
    frames = frame_signal(x, frame_len, hop, window="boxcar")
    return np.sqrt(np.mean(frames ** 2, axis=1) + 1e-12)


def zero_crossing_rate(x: np.ndarray, frame_len: int, hop: int) -> np.ndarray:
    frames = frame_signal(x, frame_len, hop, window="boxcar")
    signs = np.sign(frames)
    signs[signs == 0] = 1
    zcr = np.mean(np.abs(np.diff(signs, axis=1)) > 0, axis=1)
    return zcr


def bandpass(x: np.ndarray, sr: int, low: float, high: float, order: int = 4) -> np.ndarray:
    nyq = sr / 2.0
    low = max(low / nyq, 1e-5)
    high = min(high / nyq, 0.999)
    b, a = butter(order, [low, high], btype="band")
    return filtfilt(b, a, x)


def highpass(x: np.ndarray, sr: int, cutoff: float, order: int = 4) -> np.ndarray:
    nyq = sr / 2.0
    norm = min(cutoff / nyq, 0.999)
    b, a = butter(order, norm, btype="high")
    return filtfilt(b, a, x)


def normalize_peak(x: np.ndarray, peak: float = 0.95) -> np.ndarray:
    m = np.max(np.abs(x))
    if m < 1e-12:
        return x.copy()
    return x * (peak / m)


def parabolic_interpolation(y: np.ndarray, idx: int) -> tuple[float, float]:
    """
    Параболическая интерполяция пика.
    Возвращает (refined_index, refined_value).
    """
    if idx <= 0 or idx >= len(y) - 1:
        return float(idx), float(y[idx])
    alpha = y[idx - 1]
    beta = y[idx]
    gamma = y[idx + 1]
    denom = alpha - 2 * beta + gamma
    if abs(denom) < 1e-12:
        return float(idx), float(beta)
    p = 0.5 * (alpha - gamma) / denom
    refined_idx = idx + p
    refined_val = beta - 0.25 * (alpha - gamma) * p
    return refined_idx, refined_val


def median_smooth(x: np.ndarray, kernel: int = 5) -> np.ndarray:
    if kernel % 2 == 0:
        kernel += 1
    return medfilt(x, kernel_size=kernel)


def safe_log(x: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    return np.log(np.maximum(x, eps))
