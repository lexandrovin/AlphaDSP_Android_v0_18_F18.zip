"""AlphaDSP · CPPS v0.5: кепстр по дБ-спектру, усреднение по времени, прямая тренда, пик над трендом."""
from __future__ import annotations
import numpy as np
from scipy.signal import find_peaks

def cpps(x, sr, fmin=60.0, fmax=330.0, frame_ms=40.0, hop_ms=2.0, smooth_frames=10, gate_db=-35.0):
    x = np.asarray(x, float); n = int(sr*frame_ms/1000); hop = max(1, int(sr*hop_ms/1000))
    if len(x) < n+hop: return None
    idx = np.arange(0, len(x)-n, hop)
    W = np.lib.stride_tricks.sliding_window_view(x, n)[idx]
    W = W - W.mean(1, keepdims=True)
    e = 10*np.log10((W**2).mean(1)+1e-20); act = e > e.max()+gate_db     # только не-тишина
    if act.sum() < 5: return None
    nfft = 2048; w = np.hanning(n)
    S = 20*np.log10(np.abs(np.fft.rfft(W*w, nfft, axis=1))+1e-9)
    C = np.abs(np.fft.irfft(S, nfft, axis=1)[:, :nfft//2])                 # модуль кепстра
    k = smooth_frames
    Cs = np.apply_along_axis(lambda c: np.convolve(c, np.ones(k)/k, "same"), 0, C)   # усреднение по времени
    q = np.arange(nfft//2)/sr; lo, hi = int(sr/fmax), int(sr/fmin)
    vals = []
    for i in np.where(act)[0][::5]:
        c = 20*np.log10(Cs[i, lo:hi]+1e-12); qq = q[lo:hi]                 # кепстр в дБ
        p = np.polyfit(qq, c, 1)                                           # тренд в окне поиска
        pk = (c - np.polyval(p, qq)).max()
        vals.append(pk)
    return float(np.median(vals)) if vals else None
