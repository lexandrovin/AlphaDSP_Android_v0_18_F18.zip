# v0.6: многокадровый LPC с вычитанием шума (см. константы _K, _NR, _NRQ, _NRP)
"""AlphaDSP · RobustFormants (v0.4)
Замена AdaptiveLPCFormants с тем же интерфейсом: RobustFormants(sr).estimate(x) -> FormantSummary.
Идея: (1) перебор потолка частот 4500-6500 Гц со сжатием сигнала (как лучшие ручные методы),
(2) LPC Burg порядка 2*n, (3) Viterbi вместо "ближайшего соседа", (4) выбор потолка по цене лучшего пути.
Веса цен (_TR, _PRI, _SIG и числа в _states) — настраиваемые.
Стиль кода: без отступов (однострочные функции), чтобы удобно править на планшете."""
from __future__ import annotations
import functools, itertools
from math import gcd
import numpy as np
from scipy.signal import resample_poly
from scipy.stats import trim_mean
from numpy.lib.stride_tricks import sliding_window_view as _swv
from alpha_dsp.core.formants import FormantTrack, FormantSummary
_TR = 10.0
_PRI = np.array([500.0, 1500.0, 2500.0])
_SIG = np.array([0.45, 0.40, 0.30])
_SKIP = 1.0
_BWD = 200.0
_PW = 0.5
_NR = 0.8   # вес вычитания шума в автокорреляции (0 = выкл, Burg как раньше)
_NRP = 10  # перцентиль энергии кадров, из которых оценивается шум
_NRQ = 0.8  # вычитать, только если тихие кадры < _NRQ * медианы энергии
_TM = 0.49  # доля обрезки trim_mean (0.5 = медиана)
_K = 9  # число кадров усреднения автокорреляции (многокадровый LPC)
_WNC = 1e-4  # белый шум-«страховка» после вычитания
_comb = functools.lru_cache(None)(lambda m: np.array(list(itertools.combinations(range(m), 3))))
def _bstep(s, m): a, f, b = s; fm = f[m:].copy(); bm = b[m - 1:-1].copy(); den = fm @ fm + bm @ bm; k = 0.0 if den < 1e-14 else float(np.clip(-2 * (fm @ bm) / den, -.9999, .9999)); a = a.copy(); a[1:m] = a[1:m] + k * a[m - 1:0:-1]; a[m] = k; f = f.copy(); b = b.copy(); f[m:] = fm + k * bm; b[m:] = bm + k * fm; return a, f, b
_burg = lambda x, p: functools.reduce(_bstep, range(1, p + 1), (np.r_[1.0, np.zeros(p)], x.astype(float).copy(), x.astype(float).copy()))[0]
def _poles(a, fs, fmin, fmax, bwmax): r = np.roots(a); r = r[np.imag(r) > 1e-6]; f = np.angle(r) * fs / (2 * np.pi); bw = -np.log(np.abs(r) + 1e-15) * fs / np.pi; m = (f >= fmin) & (f <= fmax) & (bw < bwmax) & (bw > 0); o = np.argsort(f[m]); return f[m][o], bw[m][o]
def _acf(X, p): n = X.shape[1]; return np.fft.irfft(np.abs(np.fft.rfft(X, 2 * n, axis=1)) ** 2, axis=1)[:, :p + 1]
def _lpc_nr(W, win, p, K=None, NR=None):
 K = _K if K is None else K; NR = _NR if NR is None else NR
 # LPC по автокорреляции с вычитанием автокорреляции шума (оценка по самым тихим кадрам)
 from scipy.linalg import solve_toeplitz
 R = _acf(W * win, p); e = R[:, 0]; q = e <= np.percentile(e, _NRP); rn = R[q].mean(0) if NR > 0 and np.percentile(e, _NRP) < _NRQ * np.median(e) else np.zeros(p + 1)
 from scipy.ndimage import uniform_filter1d
 Rs = uniform_filter1d(R, K, axis=0, mode='nearest') if K > 1 else R
 out = []
 for r in Rs - _NR * rn:
  r = r.copy(); r[0] *= 1 + _WNC
  try: out.append(np.r_[1.0, solve_toeplitz(r[:p], -r[1:p + 1])] if r[0] > 1e-12 * max(1.0, e.max()) else None)
  except Exception: out.append(None)
 return out
def _gwin(n): t = (np.arange(n) + 0.5) / n; return (np.exp(-48 * (t - 0.5) ** 2) - np.exp(-12)) / (1 - np.exp(-12))
def _burg_batch(W, win, p):
 # Burg по всем кадрам сразу (пакетно по кадрам); как у Praat: окно, затем Burg порядка p
 f = (W * win).astype(float); b = f.copy(); F, n = f.shape; a = np.zeros((F, p + 1)); a[:, 0] = 1.0
 for m in range(1, p + 1):
  fm = f[:, m:]; bm = b[:, m - 1:n - 1]; den = (fm * fm).sum(1) + (bm * bm).sum(1); k = np.where(den < 1e-14, 0.0, np.clip(-2 * (fm * bm).sum(1) / np.where(den < 1e-14, 1.0, den), -0.9999, 0.9999))
  ap = a.copy(); a[:, 1:m] = ap[:, 1:m] + k[:, None] * ap[:, m - 1:0:-1]; a[:, m] = k; nf = fm + k[:, None] * bm; nb = bm + k[:, None] * fm; f = f.copy(); b = b.copy(); f[:, m:] = nf; b[:, m:] = nb
 return [a[i] if (W[i] ** 2).sum() > 1e-12 else None for i in range(F)]
def _poles_all(A, fs, fmin, fmax, bwmax):
 # то же, что _poles, но корни всех кадров находятся одним пакетным вызовом eigvals
 ok = [i for i, a in enumerate(A) if a is not None]; out = [None] * len(A)
 if not ok: return out
 p = len(A[ok[0]]) - 1; C = np.zeros((len(ok), p, p)); C[:, 0, :] = [-A[i][1:] / A[i][0] for i in ok]; C[:, np.arange(1, p), np.arange(p - 1)] = 1.0
 try: Rt = np.linalg.eigvals(C)
 except Exception: return [None if a is None else _poles(a, fs, fmin, fmax, bwmax) for a in A]
 for n, i in enumerate(ok):
  r = Rt[n]; r = r[np.imag(r) > 1e-6]; f = np.angle(r) * fs / (2 * np.pi); bw = -np.log(np.abs(r) + 1e-15) * fs / np.pi; m = (f >= fmin) & (f <= fmax) & (bw < bwmax) & (bw > 0); o = np.argsort(f[m]); out[i] = (f[m][o], bw[m][o])
 return out
def _states(f, bw, sc): ix = np.sort(np.argsort(bw)[:7]) if len(f) > 7 else np.arange(len(f)); f, bw = f[ix], bw[ix]; C = _comb(len(f)); lf = np.log(f[C]); d = (lf - np.log(_PRI * sc)) / _SIG; loc = (bw[C] / _BWD).sum(1) + _PW * (d ** 2).sum(1); idx = np.arange(len(f)); inC = (idx[None, :, None] == C[:, None, :]).any(2); skip = ((idx[None, :] < C[:, 2:3]) & ~inC & (bw < 250)[None, :]).sum(1); return lf, loc + _SKIP * skip, f, bw, C
def _vstep(st, it): c, Sp, bp = st; S, L = it; tot = _TR * np.abs(S[:, None, :] - Sp[None, :, :]).sum(-1) + c[None, :]; j = tot.argmin(1); return L + tot[np.arange(len(j)), j], S, bp + [j]
def _viterbi(Ss, Ls): c, _, bp = functools.reduce(_vstep, zip(Ss[1:], Ls[1:]), (Ls[0], Ss[0], [])); k = [int(c.argmin())]; [k.append(int(b[k[-1]])) for b in bp[::-1]]; return k[::-1], float(c.min())
def _fill(F, BW, c, i, s, nf): lf, loc, f, bw, C = c; k = C[s]; F[i, :3] = f[k]; BW[i, :3] = bw[k]; up = np.where(np.arange(len(f)) > k[2])[0][:nf - 3]; F[i, 3:3 + len(up)] = f[up]; BW[i, 3:3 + len(up)] = bw[up]
def _nmed(v):
 import warnings
 with warnings.catch_warnings():
  warnings.simplefilter('ignore'); return np.nanmedian(v, 0) if len(v) else np.full(3, np.nan)
def _stat(v, ok): return (float(trim_mean(v, _TM)), float(np.std(v)), float(np.clip(1.0 - np.std(v) / (np.mean(v) + 1e-6), 0, 1))) if ok else (float("nan"), float("nan"), 0.0)
def _runs(ok): d = np.diff(np.r_[0, ok.astype(int), 0]); return list(zip(np.where(d == 1)[0], np.where(d == -1)[0]))
_RK = ([8.5383, 30.4239, -38.6919], [23.5623, 23.6783, 14.4032], [0.6531, -0.3891, 1.0295], -1.6667)  # (mu, sd, coef, bias) логистической модели риска провала F2; None -> флаг не считается
_RK_THR = 0.3  # риск >= порога -> F2 помечается UNDET (last_f2_undet)
_MODEL = [False, None]
def _model():
 # обученная (на синтетике с известной истиной) модель выбора потолка отдельно для F1..F3; нет файла -> None
 import os
 if not _MODEL[0]:
  _MODEL[0] = True
  try: _MODEL[1] = dict(np.load(os.path.join(os.path.dirname(__file__), "ceil_model.npz")))
  except Exception: _MODEL[1] = None
 return _MODEL[1]
def _mpred(M, k, X):
 # предсказание ошибки (log) для строк X; все деревья обходятся одновременно (массивы T x узлы)
 if f"P{k}" not in M:
  o = M[f"o{k}"]; T = len(o) - 1; N = int(np.max(np.diff(o))); P = {}
  for nm, dt in (("f", np.int32), ("t", np.float64), ("l", np.int32), ("r", np.int32), ("v", np.float64), ("m", bool), ("leaf", bool)):
   A = np.zeros((T, N), dtype=dt)
   for i in range(T): seg = M[f"{nm}{k}"][o[i]:o[i + 1]]; A[i, :len(seg)] = seg
   P[nm] = A
  M[f"P{k}"] = P
 P = M[f"P{k}"]; T = P["f"].shape[0]; R = len(X); tt = np.arange(T)[:, None]; rr = np.arange(R)[None, :]; idx = np.zeros((T, R), dtype=int)
 for _ in range(16):
  lf = P["leaf"][tt, idx]
  if lf.all(): break
  x = X[rr, np.maximum(P["f"][tt, idx], 0)]; go_l = np.where(np.isnan(x), P["m"][tt, idx], x <= P["t"][tt, idx]); idx = np.where(lf, idx, np.where(go_l, P["l"][tt, idx], P["r"][tt, idx]))
 return float(M[f"b{k}"]) + P["v"][tt, idx].sum(0)
class RobustFormants:
 def __init__(self, sr=16000, n_formants=5, frame_ms=25.0, hop_ms=10.0, ceilings=(4500, 5000, 5500, 6000, 6500), preemph_hz=50.0, low_ratio=0.5, **_ignored): self.sr, self.nf, self.frame_ms, self.hop_ms, self.preemph_hz, self.low_ratio = sr, n_formants, frame_ms, hop_ms, preemph_hz, low_ratio; self.ceilings = list(ceilings); self.last_ceiling = None; self.last_scores = {}
 def _frames(self, x, fs): fl = int(round(fs * self.frame_ms / 1000)); hop = int(round(fs * self.hop_ms / 1000)); W = _swv(np.pad(x, (0, max(0, fl - len(x)))), fl)[::hop]; return W, (np.arange(len(W)) * hop + fl / 2) / fs, fl
 def _active(self, x): W, t, fl = self._frames(x, self.sr); rms = np.sqrt((W ** 2).mean(1)); P = np.abs(np.fft.rfft(W * np.hanning(fl), axis=1)) ** 2; fr = np.fft.rfftfreq(fl, 1 / self.sr); lo = P[:, fr < 1500].sum(1) / (P.sum(1) + 1e-20); return t, (rms > max(1e-4, 0.05 * rms.max())) & (lo >= self.low_ratio)
 def _resample(self, x, ceil): fs = 2.0 * ceil; g = gcd(int(round(fs)), self.sr); up, dn = int(round(fs)) // g, self.sr // g; xr = resample_poly(x, up, dn); fs = self.sr * up / dn; c = np.exp(-2 * np.pi * self.preemph_hz / fs); return np.r_[xr[0], xr[1:] - c * xr[:-1]], fs
 def _floor(self, x):
  # уровень шумовой «полки» 1.5-4 кГц относительно максимума <1 кГц (дБ) по активным кадрам; высокий -> F2/F3 тонут в шуме
  W, t, fl = self._frames(x, self.sr); at, act = self._active(x); n = min(len(act), len(W))
  if n == 0 or act[:n].sum() < 3: return float('nan')
  P = (np.abs(np.fft.rfft(W[:n][act[:n]] * np.hanning(fl), axis=1)) ** 2).mean(0); fr = np.fft.rfftfreq(fl, 1 / self.sr)
  return float(10 * np.log10(np.median(P[(fr > 1500) & (fr < 4000)]) / P[fr < 1000].max()))
 def _risk(self, f):
  if _RK is None or not np.all(np.isfinite(f)): return float('nan')
  z = (np.array(f) - _RK[0]) / _RK[1]; return float(1 / (1 + np.exp(-(z @ _RK[2] + _RK[3]))))
 def _one(self, a, fs, ceil): f, bw = _poles(a, fs, 90.0, ceil - 50.0, 600.0); return _states(f, bw, ceil / 5000.0) if len(f) >= 3 else None
 def _cands(self, xr, fs, ceil): W, t, fl = self._frames(xr, fs); win = np.hanning(fl); A = _lpc_nr(W, win, 2 * self.nf) if _NR > 0 else [_burg(w * win, 2 * self.nf) for w in W]; P = _poles_all(A, fs, 90.0, ceil - 50.0, 600.0); self._nv = np.array([p[0][:3] if p is not None and len(p[0]) >= 3 else [np.nan] * 3 for p in P]); self._nv3 = np.array([q[0][:3] if q is not None and len(q[0]) >= 3 else [np.nan] * 3 for q in _poles_all(_burg_batch(W, _gwin(fl), 2 * self.nf), fs, 50.0, ceil - 50.0, 5000.0)]); self._nv2 = np.array([q[0][:3] if q is not None and len(q[0]) >= 3 else [np.nan] * 3 for q in _poles_all(_lpc_nr(W, win, 2 * self.nf, K=1, NR=0.0), fs, 90.0, ceil - 50.0, 600.0)]); return t, [(None if p is None or len(p[0]) < 3 else _states(p[0], p[1], ceil / 5000.0)) for p in P]
 def _solve(self, t, cands, act_t, act): a = act[np.clip(np.round((t - act_t[0]) / (self.hop_ms / 1000)).astype(int), 0, len(act) - 1)]; ok = np.array([c is not None for c in cands]) & a; R = [(s, e, _viterbi([cands[i][0] for i in range(s, e)], [cands[i][1] for i in range(s, e)])) for s, e in _runs(ok)]; paths = {i: p for s, e, (path, _) in R for i, p in zip(range(s, e), path)}; return paths, ok, (sum(c for _, _, (_, c) in R) + 6.0 * int((~ok & a).sum())) / max(1, int(ok.sum()))
 def _chunk(self, x, act): W = int(4.0 / (self.hop_ms / 1000)); return (0, len(x)) if len(act) <= W else (lambda i: (int(i * self.hop_ms / 1000 * self.sr), int((i + W) * self.hop_ms / 1000 * self.sr)))(int(np.argmax(np.convolve(act.astype(float), np.ones(W), "valid"))))
 def _score(self, xc, ct, ca, c): xr, fs = self._resample(xc, c); t, cd = self._cands(xr, fs, c); sol = self._solve(t, cd, ct, ca); self._memo[c] = (t, cd, sol); self._nvm[c] = (self._nv, self._nv2, self._nv3); return sol[2]
 def _run(self, x, act_t, act): a, b = self._chunk(x, act); xc = x[a:b]; ct, ca = self._active(xc); self._memo = {}; self._nvm = {}; self.last_scores = {c: self._score(xc, ct, ca, c) for c in self.ceilings}; best = min(self.last_scores, key=self.last_scores.get); self.last_ceiling = best; t, cd, (paths, ok, _) = self._memo[best] if b - a == len(x) else (lambda xr_fs: (lambda tc: (tc[0], tc[1], self._solve(tc[0], tc[1], act_t, act)))(self._cands(xr_fs[0], xr_fs[1], best)))(self._resample(x, best)); F = np.full((len(t), self.nf), np.nan); BW = F.copy(); [_fill(F, BW, cd[i], i, s, self.nf) for i, s in paths.items()]; _nvs = self._nvm[best] if b - a == len(x) else (self._nv, self._nv2, self._nv3); self.last_naive = _nmed(_nvs[0][ok]); self.last_naive2 = _nmed(_nvs[1][ok]); self.last_naive3 = _nmed(_nvs[2][ok]); return t, F, BW
 def _select(self, x):
  # прогон по каждому потолку; кандидаты: 3 разметки (Viterbi, наивная по частоте на LPC с вычитанием шума, наивная на «сыром» LPC) x потолки;
  # обученная модель выбирает кандидата отдельно для F1, F2, F3 (для F2 без «сырой» разметки)
  M = _model(); fr = _swv(np.pad(x, (0, max(0, 400 - len(x)))), 400)[::160]; e = 10 * np.log10((fr ** 2).mean(1) + 1e-12); snr = np.percentile(e, 90) - np.percentile(e, 10); R = []
  for c in self.ceilings: sub = RobustFormants(self.sr, self.nf, self.frame_ms, self.hop_ms, (c,), self.preemph_hz, self.low_ratio); sm = sub.estimate(x, _single=True); R.append((c, sm, sub.last_scores.get(c, np.nan), sub.last_naive, sub.last_naive2, sub.last_naive3))
  n = len(R); sc = np.array([r[2] for r in R]); smin = np.nanmin(sc) if np.isfinite(sc).any() else np.nan
  E = np.array([[r[1].means[f"F{k}_mean"] for k in (1, 2, 3)] for r in R] + [list(r[3]) for r in R] + [list(r[4]) for r in R] + [list(r[5]) for r in R], dtype=float)
  L = 4; lab = np.repeat(np.arange(L), n); ce = np.tile(self.ceilings, L).astype(float); sc3 = np.tile(sc, L)
  import warnings
  with warnings.catch_warnings():
   warnings.simplefilter("ignore"); med0 = np.nanmedian(E[:n], 0); medall = np.nanmedian(E, 0); sd = np.nanstd(E, 0, ddof=1)
  X = np.column_stack([ce, sc3, sc3 - smin, np.full(L * n, smin), np.full(L * n, snr), lab, E, E - med0, E - medall, np.tile(sd, (L * n, 1))]).astype(float)
  self.last_scores = {r[0]: r[2] for r in R}; ib = int(np.nanargmin(sc)) if np.isfinite(sc).any() else 0; self.last_ceiling = R[ib][0] if np.isfinite(sc).any() else None; self.last_choice = {}
  self.last_feat = (float(smin), float(snr), self._floor(x)); self.last_f2_risk = self._risk(self.last_feat); self.last_f2_undet = bool(self.last_f2_risk >= _RK_THR) if self.last_f2_risk == self.last_f2_risk else False
  best = R[ib][1]; means, stds, stab = dict(best.means), dict(best.stds), dict(best.stability)
  for k in (1, 2, 3):
   p = _mpred(M, k, X); p[np.isnan(E[:, k - 1])] = np.inf
   p[~np.isin(lab, M[f"mask{k}"])] = np.inf
   if np.isfinite(p).any():
    j = int(np.argmin(p)); i = j % n; self.last_choice[k] = (R[i][0], int(lab[j])); sm = R[i][1]; means[f"F{k}_mean"] = float(E[j, k - 1]); stds[f"F{k}_std"] = sm.stds[f"F{k}_std"]; stab[f"F{k}"] = sm.stability[f"F{k}"]
  return FormantSummary(tracks=best.tracks, means=means, stds=stds, stability=stab)
 def estimate(self, x, _single=False):
  x = np.asarray(x, dtype=np.float64)
  if not _single and len(self.ceilings) > 1 and self.sr == 16000 and self.nf >= 3 and _model() is not None: return self._select(x - x.mean())
  return self._estimate(x)
 def _estimate(self, x): x = np.asarray(x, dtype=np.float64); x = x - x.mean(); act_t, act = self._active(x); t, F, BW = self._run(x, act_t, act) if act.sum() >= 5 else (np.array([0.0]), np.full((1, self.nf), np.nan), np.full((1, self.nf), np.nan)); return self._pack(t, F, BW)
 def _pack(self, t, F, BW): ST = [_stat(F[:, j][~np.isnan(F[:, j])], (~np.isnan(F[:, j])).sum() >= 5) for j in range(self.nf)]; conf = np.where(np.isnan(F), 0.0, np.clip(1.0 - np.nan_to_num(BW, nan=600.0) / 600.0, 0.15, 1.0)); return FormantSummary(tracks=FormantTrack(times=t, F=F, bandwidths=BW, confidence=conf), means={f"F{j + 1}_mean": ST[j][0] for j in range(self.nf)}, stds={f"F{j + 1}_std": ST[j][1] for j in range(self.nf)}, stability={f"F{j + 1}": ST[j][2] for j in range(self.nf)})
