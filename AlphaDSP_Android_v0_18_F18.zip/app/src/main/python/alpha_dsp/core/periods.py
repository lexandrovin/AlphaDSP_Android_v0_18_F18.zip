"""
AlphaDSP · Robust glottal period detection + jitter / shimmer (v0.2)

Исправления:
- Периоды строятся строго по F0-контуру (без свободного поиска пиков)
- Амплитуда берётся как max abs в окне периода (стабильнее)
- Более мягкий порог для reliability
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from alpha_dsp.core.f0 import F0Result


@dataclass
class Period:
    start: int
    end: int
    period_len: float
    peak_amp: float
    confidence: float
    seg: int = 0
    amp_nv: float = 0.0  # дисперсия шумовой ошибки амплитуды (для поправки shimmer)


@dataclass
class PerturbationResult:
    periods: list[Period]
    jitter_local: Optional[float]
    jitter_rap: Optional[float]
    jitter_ppq5: Optional[float]
    shimmer_local: Optional[float]
    shimmer_apq3: Optional[float]
    shimmer_apq5: Optional[float]
    n_periods: int
    mean_period_s: Optional[float]
    mean_f0: Optional[float]
    reliability: str
    reliability_reason: str


class PeriodDetector:
    """v0.3: реальные циклы по форме сигнала (кросс-корреляция соседних циклов,
    суб-сэмпловая точность), а не периоды из сглаженного F0-контура."""

    def __init__(self, sr: int = 16000, min_confidence: float = 0.25,
                 up: int = 8, ncc_min: float = 0.6, lp_hz: float = 2000.0, start_tries: int = 4):
        self.start_tries = start_tries
        self.sr = sr
        self.min_confidence = min_confidence
        self.up = up
        self.ncc_min = ncc_min
        self.lp_hz = lp_hz

    def detect(self, x: np.ndarray, f0_result: F0Result) -> list[Period]:
        # если при основном пороге схожести циклов периодов почти нет (напр. почти синусоидальные гласные у детей),
        # повторяем с более мягкими порогами
        for ncc in (self.ncc_min, 0.5, 0.4):
            if ncc > self.ncc_min: continue
            periods = self._detect(x, f0_result, ncc)
            if len(periods) >= 15: break
        return periods

    def _detect(self, x: np.ndarray, f0_result: F0Result, ncc_min: float) -> list[Period]:
        from scipy.signal import butter, sosfiltfilt, resample_poly
        from numpy.lib.stride_tricks import sliding_window_view
        x = np.asarray(x, dtype=np.float64) - np.mean(x)
        sr, up = self.sr, self.up
        periods: list[Period] = []
        voiced_idx = np.where(f0_result.voiced & (f0_result.confidence >= self.min_confidence))[0]
        if len(voiced_idx) == 0 or len(x) < sr * 0.1:
            return periods
        sos = butter(4, min(self.lp_hz, 0.45 * sr) / (sr / 2), output="sos")
        xu = resample_poly(sosfiltfilt(sos, x), up, 1)
        fs_u = sr * up
        f0v = f0_result.f0.copy()
        med = np.nanmedian(f0v[voiced_idx])
        f0v[np.isnan(f0v)] = med
        f0_at = lambda t: float(np.interp(t, f0_result.times, f0v))

        segments, st, pv = [], voiced_idx[0], voiced_idx[0]
        for i in voiced_idx[1:]:
            if i == pv + 1: pv = i
            else: segments.append((st, pv)); st = pv = i
        segments.append((st, pv))

        seg_id = 0
        for a, b in segments:
            t_start = f0_result.times[a]
            t_end = f0_result.times[b] + 0.5 * (f0_result.times[1] - f0_result.times[0]) if len(f0_result.times) > 1 else f0_result.times[b]
            T = fs_u / max(f0_at(t_start), 50.0)
            i0 = int(t_start * fs_u)
            n_before = len(periods)
            # если цепочка циклов не пошла (напр., старт на переходном участке) — сдвигаем старт на период и пробуем снова
            for attempt in range(self.start_tries):
                i0a = i0 + int(attempt * T)
                if i0a + int(1.3 * T) >= len(xu): break
                n_try = len(periods)
                p = float(i0a + np.argmax(xu[i0a:i0a + int(1.0 * T)]))
                while p / fs_u < t_end:
                    T = fs_u / max(f0_at(p / fs_u), 50.0)
                    h = int(0.35 * T); pi = int(round(p))
                    lo, hi = int(pi + 0.75 * T), int(pi + 1.25 * T)
                    if pi - h < 0 or hi + h + 1 >= len(xu): break
                    tm = xu[pi - h:pi + h + 1]; tm = tm - tm.mean()
                    win = sliding_window_view(xu[lo - h:hi + h + 1], 2 * h + 1)
                    win = win - win.mean(axis=1, keepdims=True)
                    ncc = (win @ tm) / (np.linalg.norm(win, axis=1) * np.linalg.norm(tm) + 1e-12)
                    j = int(np.argmax(ncc)); v = float(ncc[j])
                    if v < ncc_min: break
                    d = 0.0
                    if 0 < j < len(ncc) - 1:
                        den = ncc[j - 1] - 2 * ncc[j] + ncc[j + 1]
                        if den < 0: d = float(np.clip(0.5 * (ncc[j - 1] - ncc[j + 1]) / den, -1, 1))
                    c = lo + j + d
                    # окно амплитуды центрировано на опорной точке цикла (иначе пик на границе окна «делится» между циклами)
                    half = 0.5 * (c - pi)
                    s0, s1 = int((pi - half) / up), int((pi + half) / up)
                    if s0 >= 0 and s1 - s0 >= 3 and s1 < len(x):
                        periods.append(Period(start=s0, end=s1, period_len=float((c - pi) / up),
                                              peak_amp=float(np.ptp(x[s0:s1])), confidence=v, seg=seg_id))
                    p = c
                if len(periods) - n_try >= 5: break
                del periods[n_try:]
            if len(periods) > n_before: seg_id += 1
        self._project_amplitudes(x, periods)
        return periods

    def _project_amplitudes(self, x: np.ndarray, periods: list[Period], npt: int = 64) -> None:
        """v0.10: амплитуда периода = проекция на медианный цикл сегмента (сигнал < lp_hz) вместо размаха;
        шум оценивается по самым тихим кадрам файла и хранится в amp_nv."""
        from scipy.signal import butter, sosfiltfilt
        if len(periods) < 3: return
        xl = sosfiltfilt(butter(4, self.lp_hz / (self.sr / 2), output="sos"), x)
        fr = np.lib.stride_tricks.sliding_window_view(xl, 400)[::160] if len(xl) >= 400 else None
        sn = 0.0
        if fr is not None and len(fr) > 10:
            e = (fr ** 2).mean(1); lo = np.percentile(e, 10)
            if lo < 0.5 * np.median(e): sn = float(e[e <= lo].mean())
        grid = np.arange(len(xl)); S = np.array([np.interp(np.linspace(q.start, q.end, npt), grid, xl) for q in periods]); seg = np.array([q.seg for q in periods])
        for g in np.unique(seg):
            idx = np.where(seg == g)[0]; T = np.median(S[idx], axis=0); tt = float(T @ T) + 1e-20
            for i in idx: periods[i].peak_amp = float(S[i] @ T / tt); periods[i].amp_nv = sn / tt


class PerturbationAnalyzer:
    def __init__(self, sr: int = 16000, min_periods: int = 15, noise_k: float = 2.5):
        self.noise_k = noise_k
        self.sr = sr
        self.min_periods = min_periods

    def analyze(self, periods: list[Period]) -> PerturbationResult:
        if len(periods) < self.min_periods:
            return PerturbationResult(
                periods=periods,
                jitter_local=None, jitter_rap=None, jitter_ppq5=None,
                shimmer_local=None, shimmer_apq3=None, shimmer_apq5=None,
                n_periods=len(periods), mean_period_s=None, mean_f0=None,
                reliability="UNDET",
                reliability_reason=f"too few periods ({len(periods)} < {self.min_periods})",
            )

        good = [p for p in periods if p.confidence >= 0.25]
        if len(good) < self.min_periods:
            good = periods  # fallback

        lens = np.array([p.period_len for p in good])
        amps = np.array([p.peak_amp for p in good])
        mean_len = float(np.mean(lens))
        mean_amp = float(np.mean(amps) + 1e-12)

        seg = np.array([p.seg for p in good])
        ok1 = seg[1:] == seg[:-1]
        ok3 = (seg[2:] == seg[1:-1]) & (seg[1:-1] == seg[:-2])
        ok5 = np.array([seg[i - 2] == seg[i + 2] for i in range(2, len(seg) - 2)], dtype=bool)
        mean = lambda v, m: float(np.mean(np.asarray(v)[m])) if len(v) and np.any(m) else None

        # Jitter (только внутри непрерывных сегментов)
        jitter_local = (mean(np.abs(np.diff(lens)), ok1) or 0.0) / mean_len if np.any(ok1) else None
        rap = [abs(lens[i] - (lens[i-1] + lens[i] + lens[i+1]) / 3) for i in range(1, len(lens)-1)]
        jitter_rap = (mean(rap, ok3) / mean_len) if mean(rap, ok3) is not None else None
        ppq = [abs(lens[i] - np.mean(lens[i-2:i+3])) for i in range(2, len(lens)-2)]
        jitter_ppq5 = (mean(ppq, ok5) / mean_len) if mean(ppq, ok5) is not None else None

        # Shimmer
        shimmer_local = (mean(np.abs(np.diff(amps)), ok1) / mean_amp) if np.any(ok1) else None
        if shimmer_local is not None:
            # поправка на шум измерения амплитуды: E|dA| уменьшается по вкладу шума в дисперсию разностей
            nvs = np.array([p.amp_nv for p in good]); nv = mean(nvs[1:] + nvs[:-1], ok1); vo = mean(np.diff(amps) ** 2, ok1)
            if nv and vo: shimmer_local *= float(np.sqrt(max(0.0, 1.0 - self.noise_k * nv / (vo + 1e-20))))
        a3 = [abs(amps[i] - (amps[i-1] + amps[i] + amps[i+1]) / 3) for i in range(1, len(amps)-1)]
        shimmer_apq3 = (mean(a3, ok3) / mean_amp) if mean(a3, ok3) is not None else None
        a5 = [abs(amps[i] - np.mean(amps[i-2:i+3])) for i in range(2, len(amps)-2)]
        shimmer_apq5 = (mean(a5, ok5) / mean_amp) if mean(a5, ok5) is not None else None

        mean_conf = float(np.mean([p.confidence for p in good]))
        cv = float(np.std(lens) / mean_len) if mean_len > 0 else 1.0

        if mean_conf >= 0.45 and cv < 0.08 and len(good) >= 25:
            rel, reason = "HIGH", "stable periodic signal"
        elif mean_conf >= 0.30 and cv < 0.18 and len(good) >= 15:
            rel, reason = "MED", "moderately stable"
        elif cv > 0.30:
            rel, reason = "UNDET", "high aperiodicity (possible Type-3)"
        else:
            rel, reason = "LOW", "borderline periodicity"

        mean_period_s = mean_len / self.sr
        mean_f0 = 1.0 / mean_period_s if mean_period_s > 0 else None

        return PerturbationResult(
            periods=good,
            jitter_local=jitter_local,
            jitter_rap=jitter_rap,
            jitter_ppq5=jitter_ppq5,
            shimmer_local=shimmer_local,
            shimmer_apq3=shimmer_apq3,
            shimmer_apq5=shimmer_apq5,
            n_periods=len(good),
            mean_period_s=mean_period_s,
            mean_f0=mean_f0,
            reliability=rel,
            reliability_reason=reason,
        )
