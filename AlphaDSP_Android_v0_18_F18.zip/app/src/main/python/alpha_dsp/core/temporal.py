"""
AlphaDSP · Temporal structure: pauses, VAD, VOT (v0.2)

Исправления VOT:
- Более жёсткий порог на burst
- VOT только если есть чёткий gap между burst и voicing
- Ограничение числа событий
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import binary_opening, binary_closing

from alpha_dsp.utils.signal import (
    frame_signal,
    rms_energy,
    zero_crossing_rate,
    highpass,
)


@dataclass
class Pause:
    start: float
    end: float
    duration: float


@dataclass
class VOTEvent:
    burst_time: float
    voicing_onset: float
    vot_ms: float
    confidence: float
    place_hint: str


@dataclass
class TemporalResult:
    pauses: list[Pause]
    n_pauses: int
    total_pause_s: float
    speech_duration_s: float
    pause_ratio: float
    vad_mask: np.ndarray
    vad_times: np.ndarray
    vot_events: list[VOTEvent]


class TemporalAnalyzer:
    def __init__(
        self,
        sr: int = 16000,
        frame_ms: float = 20.0,
        hop_ms: float = 10.0,
        min_pause_s: float = 0.08,
    ):
        self.sr = sr
        self.frame_len = int(sr * frame_ms / 1000)
        self.hop = int(sr * hop_ms / 1000)
        self.min_pause_s = min_pause_s

    def _spectral_flux(self, frames: np.ndarray) -> np.ndarray:
        from scipy.fft import rfft
        specs = np.abs(rfft(frames, axis=1))
        flux = np.zeros(len(frames))
        for i in range(1, len(frames)):
            diff = specs[i] - specs[i - 1]
            flux[i] = np.sqrt(np.sum(np.maximum(diff, 0) ** 2))
        return flux

    def _vad(self, x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        frames = frame_signal(x, self.frame_len, self.hop, window="hann")
        n = len(frames)
        times = (np.arange(n) * self.hop + self.frame_len // 2) / self.sr

        energy = np.sqrt(np.mean(frames ** 2, axis=1) + 1e-12)
        energy_db = 20 * np.log10(energy / (np.max(energy) + 1e-12) + 1e-12)
        zcr = zero_crossing_rate(x, self.frame_len, self.hop)
        flux = self._spectral_flux(frames)
        flux_norm = flux / (np.max(flux) + 1e-12)

        e_thresh = np.percentile(energy_db, 25) + 4.0
        zcr_ok = (zcr > 0.015) & (zcr < 0.40)
        raw = (energy_db > e_thresh) & zcr_ok
        raw = binary_closing(raw, structure=np.ones(3))
        raw = binary_opening(raw, structure=np.ones(2))
        return raw.astype(bool), times

    def _extract_pauses(self, vad_mask: np.ndarray, times: np.ndarray) -> list[Pause]:
        pauses = []
        in_pause = False
        start = 0.0
        for i, speech in enumerate(vad_mask):
            if not speech and not in_pause:
                in_pause = True
                start = times[i]
            elif speech and in_pause:
                in_pause = False
                dur = times[i] - start
                if dur >= self.min_pause_s:
                    pauses.append(Pause(start=float(start), end=float(times[i]), duration=float(dur)))
        if in_pause:
            dur = times[-1] - start
            if dur >= self.min_pause_s:
                pauses.append(Pause(start=float(start), end=float(times[-1]), duration=float(dur)))
        return pauses

    def _detect_bursts(self, x: np.ndarray) -> list[float]:
        hp = highpass(x, self.sr, 3000.0)
        frame_len = int(0.004 * self.sr)
        hop = int(0.001 * self.sr)
        energy = rms_energy(hp, frame_len, hop)
        times = (np.arange(len(energy)) * hop + frame_len // 2) / self.sr
        diff = np.diff(energy, prepend=energy[0])
        # жёсткий порог — только сильные всплески
        thresh = np.percentile(diff, 97)
        peaks, _ = find_peaks(diff, height=max(thresh, np.max(diff) * 0.3), distance=int(0.05 * self.sr / hop))
        return [float(times[p]) for p in peaks]

    def analyze(
        self,
        x: np.ndarray,
        f0_times: Optional[np.ndarray] = None,
        f0_voiced: Optional[np.ndarray] = None,
    ) -> TemporalResult:
        duration = len(x) / self.sr
        vad_mask, vad_times = self._vad(x)
        pauses = self._extract_pauses(vad_mask, vad_times)
        total_pause = sum(p.duration for p in pauses)
        speech_dur = max(0.0, duration - total_pause)

        vot_events = []
        if f0_times is not None and f0_voiced is not None:
            bursts = self._detect_bursts(x)
            used_onsets = set()
            for b in bursts:
                # ищем первый voiced после burst
                onset = None
                for t, v in zip(f0_times, f0_voiced):
                    if t >= b + 0.005 and v:
                        onset = float(t)
                        break
                if onset is None:
                    continue
                vot_ms = (onset - b) * 1000.0
                if not (8.0 < vot_ms < 100.0):
                    continue
                # не дублируем близкие
                key = round(onset, 2)
                if key in used_onsets:
                    continue
                used_onsets.add(key)
                if vot_ms < 25:
                    place = "bilabial"
                elif vot_ms < 50:
                    place = "alveolar"
                else:
                    place = "velar"
                vot_events.append(VOTEvent(
                    burst_time=b, voicing_onset=onset,
                    vot_ms=float(vot_ms), confidence=0.55, place_hint=place,
                ))

        return TemporalResult(
            pauses=pauses,
            n_pauses=len(pauses),
            total_pause_s=total_pause,
            speech_duration_s=speech_dur,
            pause_ratio=total_pause / duration if duration > 0 else 0.0,
            vad_mask=vad_mask,
            vad_times=vad_times,
            vot_events=vot_events,
        )
