"""AlphaDSP · denoise v0.5: спектральное вычитание по шуму из самых тихих кадров (стационарный шум)."""
import numpy as np
def spectral_subtract(x, sr, frame_ms=32.0, alpha=1.5, beta=0.08, quiet_frac=0.1):
    n = int(sr*frame_ms/1000); hop = n//4; w = np.hanning(n)
    if len(x) < 2*n: return x
    pad = np.pad(x, (n, n)); idx = np.arange(0, len(pad)-n, hop)
    W = np.lib.stride_tricks.sliding_window_view(pad, n)[idx]*w
    S = np.fft.rfft(W, axis=1); P = np.abs(S)**2
    e = P.sum(1); q = np.argsort(e)[:max(3, int(quiet_frac*len(e)))]
    N = P[q].mean(0)
    gain = np.sqrt(np.maximum(1 - alpha*N/(P+1e-20), beta**2))
    Y = np.fft.irfft(S*gain, n, axis=1)*w
    out = np.zeros(len(pad)); norm = np.zeros(len(pad))
    for k, i in enumerate(idx): out[i:i+n] += Y[k]; norm[i:i+n] += w**2
    return (out/np.maximum(norm, 1e-8))[n:n+len(x)]
