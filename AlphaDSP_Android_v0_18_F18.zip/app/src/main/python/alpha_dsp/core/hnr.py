"""
AlphaDSP · HNR и CPPS (v0.2)

Исправления CPPS:
- Правильный noise floor (линейный тренд + медиана residual)
- Усреднение только по voiced-кадрам с достаточным peak
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.fft import rfft, irfft

from alpha_dsp.utils.signal import frame_signal, preemphasis, safe_log, parabolic_interpolation


@dataclass
class HNRResult:
    hnr_mean: Optional[float]
    hnr_std: Optional[float]
    cpps: Optional[float]
    cpps_frames: Optional[np.ndarray]
    reliability: str


class HarmonicityAnalyzer:
    def __init__(
        self,
        sr: int = 16000,
        fmin: float = 70.0,
        fmax: float = 400.0,
        frame_ms: float = 40.0,
        hop_ms: float = 10.0,
    ):
        self.sr = sr
        self.fmin = fmin
        self.fmax = fmax
        self.frame_len = int(sr * frame_ms / 1000)
        self.hop = int(sr * hop_ms / 1000)
        self.min_lag = int(sr / fmax)
        self.voicing_r = 0.35
        self.max_lag = int(sr / fmin)

    def _frame_hnr(self, frame: np.ndarray) -> Optional[float]:
        """HNR кадра по Boersma (1993): автокорреляция сигнала, делённая на
        автокорреляцию окна (иначе значения зависят от лага, т.е. от F0)."""
        n = len(frame)
        w = np.hanning(n)
        xw = (frame - np.mean(frame)) * w
        if n < self.max_lag + 10:
            return None
        nfft = 1 << (2 * n - 1).bit_length()
        up = 4  # суб-сэмпловый лаг через дополнение спектра нулями (sinc-интерполяция автокорреляции)
        px = np.abs(rfft(xw, n=nfft)) ** 2
        pw = np.abs(rfft(w, n=nfft)) ** 2
        rx = irfft(px, n=up * nfft)[:n * up]
        rw = irfft(pw, n=up * nfft)[:n * up]
        if rx[0] <= 1e-12: return None
        r = (rx / rx[0]) / (rw / rw[0] + 1e-12)
        lo, hi = self.min_lag * up, min(self.max_lag, n // 2) * up
        seg = r[lo:hi + 1]
        if len(seg) < 5: return None
        # кандидаты — локальные максимумы; берём самый короткий лаг, близкий к максимуму (против субгармоник)
        pk = np.where((seg[1:-1] >= seg[:-2]) & (seg[1:-1] > seg[2:]))[0] + 1
        if len(pk) == 0: return None
        best = seg[pk].max()
        cand = pk[seg[pk] >= 0.9 * best]
        rpk = float(seg[int(cand[0])])
        if rpk < self.voicing_r: return None
        rpk = float(np.clip(rpk, 1e-4, 1 - 1e-6))
        return float(10.0 * np.log10(rpk / (1.0 - rpk)))

    def _cpps_frame(self, frame: np.ndarray) -> Optional[float]:
        n = len(frame)
        frame = frame - np.mean(frame)
        nfft = max(2048, 1 << (n - 1).bit_length())
        mag = np.abs(rfft(frame, n=nfft))
        log_mag = safe_log(mag)
        cep = irfft(log_mag, n=nfft)

        qmin = self.min_lag
        qmax = min(self.max_lag, n // 2 - 1)
        if qmax <= qmin + 5:
            return None

        region = cep[qmin:qmax]
        x = np.arange(len(region), dtype=np.float64)
        # линейный тренд
        coef = np.polyfit(x, region, 1)
        trend = np.polyval(coef, x)
        detrended = region - trend

        peak_idx = int(np.argmax(detrended))
        peak_val = float(detrended[peak_idx])

        # noise floor = median of the lower 70% of detrended values
        sorted_d = np.sort(detrended)
        noise_floor = float(np.median(sorted_d[:max(1, int(len(sorted_d) * 0.7))]))

        cpps = peak_val - noise_floor
        # переводим в dB-подобную шкалу (cepstral values уже log)
        # Praat CPPS обычно 5–15 dB для речи
        if cpps < 0.5:
            return None
        return float(cpps)

    def analyze(self, x: np.ndarray) -> HNRResult:
        x = np.asarray(x, dtype=np.float64)
        fl = max(self.frame_len, int(3 * self.sr / max(self.fmin, 1.0)))
        raw = frame_signal(x, fl, self.hop, window="rect")          # для HNR (без пре-эмфазиса)
        cp = frame_signal(preemphasis(x, 0.97), self.frame_len, self.hop, window="hann")  # для CPPS (как раньше)
        gmax = float(np.max(np.abs(x))) + 1e-12
        hnr_vals, cpps_vals = [], []
        for fr in raw:
            if np.max(np.abs(fr)) < 0.05 * gmax:      # тишина (порог как в Praat: 0.1 от пика, здесь мягче)
                continue
            h = self._frame_hnr(fr)
            if h is not None:
                hnr_vals.append(h)
        for fr in cp:
            if np.sqrt(np.mean(fr ** 2)) < 1e-4:
                continue
            c = self._cpps_frame(fr)
            if c is not None:
                cpps_vals.append(c)

        if len(hnr_vals) < 5:
            return HNRResult(hnr_mean=None, hnr_std=None, cpps=None, cpps_frames=None, reliability="UNDET")

        hnr_mean = float(np.mean(hnr_vals))
        hnr_std = float(np.std(hnr_vals))
        cpps = float(np.median(cpps_vals)) if cpps_vals else None
        if hnr_std < 4.0 and len(hnr_vals) > 12:
            rel = "HIGH"
        elif hnr_std < 8.0:
            rel = "MED"
        else:
            rel = "LOW"
        return HNRResult(hnr_mean=hnr_mean, hnr_std=hnr_std, cpps=cpps,
                         cpps_frames=np.array(cpps_vals) if cpps_vals else None, reliability=rel)
