"""
AlphaDSP · F0 estimator v0.2

Гибрид:
1. YIN-style difference function (основной, хорошо подавляет гармоники)
2. Нормализованная автокорреляция (дополнительный)
3. Cepstrum (дополнительный)
4. Multi-candidate merge + Viterbi tracking с сильным anti-octave
5. Post-hoc octave correction по медиане
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.signal import find_peaks
from scipy.fft import rfft, irfft, rfftfreq

from alpha_dsp.utils.signal import (
    frame_signal,
    preemphasis,
    parabolic_interpolation,
    median_smooth,
    safe_log,
)


@dataclass
class F0Result:
    times: np.ndarray
    f0: np.ndarray
    confidence: np.ndarray
    voiced: np.ndarray
    candidates: Optional[list] = None


class HybridF0:
    floor_margin_db = 4.0
    def __init__(
        self,
        sr: int = 16000,
        fmin: float = 60.0,
        fmax: float = 400.0,
        frame_ms: float = 40.0,
        hop_ms: float = 10.0,
        yin_threshold: float = 0.15,
        octave_cost: float = 0.25,
        jump_cost: float = 0.30,
        voicing_threshold: float = 0.20,
        prefilter: str = "preemph",
        gate_db: float = -25.0,
    ):
        self.prefilter = prefilter
        self.gate_db = gate_db
        self.sr = sr
        self.fmin = fmin
        self.fmax = fmax
        self.frame_len = int(sr * frame_ms / 1000)
        self.hop = int(sr * hop_ms / 1000)
        self.yin_threshold = yin_threshold
        self.octave_cost = octave_cost
        self.jump_cost = jump_cost
        self.voicing_threshold = voicing_threshold
        self.min_lag = max(2, int(sr / fmax))
        self.max_lag = int(sr / fmin)

    # ------------------------------------------------------------------
    # YIN difference function (главный источник кандидатов)
    # ------------------------------------------------------------------

    def _yin_candidates(self, frame: np.ndarray, n_cand: int = 4, pre=None) -> list[tuple[float, float]]:
        """
        Cumulative Mean Normalized Difference Function (YIN).
        Возвращает (f0, salience), где salience = 1 - d'(tau).
        """
        n = len(frame)
        if pre is None:
            frame = frame - np.mean(frame)
        max_lag = min(self.max_lag, n // 2)
        min_lag = self.min_lag

        # difference function: d(tau) = sum x[j]^2 (j<n-tau) + sum x[j]^2 (j>=tau) - 2 r(tau); r через FFT
        if pre is None:
            nf = 1 << int(np.ceil(np.log2(2 * n)))
            r = np.fft.irfft(np.abs(np.fft.rfft(frame, nf)) ** 2, nf)[:max_lag + 1]
            cs = np.r_[0.0, np.cumsum(frame * frame)]
        else:
            r, cs = pre[0][:max_lag + 1], pre[1]
        tau_ = np.arange(max_lag + 1)
        d = cs[n - tau_] + (cs[n] - cs[tau_]) - 2.0 * r
        d[0] = 0.0
        d = np.maximum(d, 0.0)

        # cumulative mean normalized
        d_norm = np.ones(max_lag + 1)
        d_norm[1:] = d[1:] * tau_[1:] / (np.cumsum(d[1:]) + 1e-12)

        # ищем минимумы
        search = d_norm[min_lag:max_lag + 1]
        inv = -search
        peaks, props = find_peaks(inv, height=-0.7, distance=max(3, min_lag // 4))
        if len(peaks) == 0:
            idx = int(np.argmin(search))
            peaks = np.array([idx])
            props = {"peak_heights": np.array([-search[idx]])}

        cands = []
        # 1) ВСЕГДА берём самый низкочастотный разумный минимум (anti-octave)
        for p in sorted(peaks):
            tau = p + min_lag
            if d_norm[tau] < 0.65:
                refined_tau, _ = parabolic_interpolation(d_norm, tau)
                if refined_tau > 0:
                    f0 = self.sr / refined_tau
                    if self.fmin <= f0 <= self.fmax:
                        # salience чуть снижена, но кандидат гарантированно присутствует
                        sal = float(np.clip(1.0 - d_norm[tau], 0.15, 1.0))
                        cands.append((float(f0), sal * 1.1))  # бонус за низкую частоту
                        break

        # 2) Остальные — по глубине минимума
        heights = props["peak_heights"]
        order = np.argsort(heights)[::-1]
        for i in order:
            if len(cands) >= n_cand:
                break
            tau = peaks[i] + min_lag
            refined_tau, _ = parabolic_interpolation(d_norm, tau)
            if refined_tau <= 0:
                continue
            f0 = self.sr / refined_tau
            if self.fmin <= f0 <= self.fmax:
                # не дублируем близкий к уже добавленному
                if any(abs(1200 * np.log2(f0 / c[0])) < 40 for c in cands):
                    continue
                sal = float(np.clip(1.0 - d_norm[tau], 0, 1))
                cands.append((float(f0), sal))
        return cands

    def _nac_candidates(self, frame: np.ndarray, n_cand: int = 3, ac=None) -> list[tuple[float, float]]:
        n = len(frame)
        if ac is None:
            frame = frame - np.mean(frame)
            nfft = 1 << (n * 2 - 1).bit_length()
            ac = irfft(np.abs(rfft(frame, n=nfft)) ** 2, n=nfft)[:n]
        else:
            ac = ac.copy()
        ac /= (ac[0] + 1e-12)

        search = ac[self.min_lag:self.max_lag + 1]
        if len(search) < 3:
            return []
        peaks, props = find_peaks(search, height=0.12, distance=max(3, self.min_lag // 3))
        if len(peaks) == 0:
            return []
        heights = props["peak_heights"]
        order = np.argsort(heights)[::-1][:n_cand]
        cands = []
        for i in order:
            lag = peaks[i] + self.min_lag
            refined, h = parabolic_interpolation(ac, lag)
            if refined > 0:
                f0 = self.sr / refined
                if self.fmin <= f0 <= self.fmax:
                    cands.append((float(f0), float(h)))
        return cands

    def _cepstrum_candidates(self, frame: np.ndarray, n_cand: int = 2, cep=None) -> list[tuple[float, float]]:
        n = len(frame)
        if cep is None:
            frame = frame - np.mean(frame)
            spec = rfft(frame, n=n)
            cep = irfft(safe_log(np.abs(spec)), n=n)
        qmin = self.min_lag
        qmax = min(self.max_lag, n // 2)
        search = cep[qmin:qmax]
        if len(search) < 3:
            return []
        peaks, props = find_peaks(search, height=np.max(search) * 0.15, distance=max(3, qmin // 3))
        if len(peaks) == 0:
            return []
        heights = props["peak_heights"]
        order = np.argsort(heights)[::-1][:n_cand]
        cands = []
        max_h = np.max(heights) + 1e-12
        for i in order:
            q = peaks[i] + qmin
            refined, h = parabolic_interpolation(cep, q)
            if refined > 0:
                f0 = self.sr / refined
                if self.fmin <= f0 <= self.fmax:
                    cands.append((float(f0), float(h / max_h)))
        return cands

    def _merge_candidates(
        self,
        yin: list,
        nac: list,
        cep: list,
        merge_tol_cents: float = 40.0,
    ) -> list[tuple[float, float]]:
        all_cands: list[tuple[float, float]] = []
        # YIN — главный, вес 1.2
        for f, s in yin:
            all_cands.append((f, s * 1.2))
        for f, s in nac:
            all_cands.append((f, s * 0.7))
        for f, s in cep:
            all_cands.append((f, s * 0.5))

        if not all_cands:
            return []

        all_cands.sort(key=lambda x: x[0])
        clusters: list[list[tuple[float, float]]] = [[all_cands[0]]]
        for f, s in all_cands[1:]:
            prev_f = clusters[-1][-1][0]
            cents = 1200 * np.log2(f / prev_f) if prev_f > 0 else 999
            if abs(cents) < merge_tol_cents:
                clusters[-1].append((f, s))
            else:
                clusters.append([(f, s)])

        merged = []
        for cl in clusters:
            total_s = sum(s for _, s in cl)
            if total_s < 1e-8:
                continue
            f_avg = sum(f * s for f, s in cl) / total_s
            # бонус за низкую частоту (предпочтение фундамента)
            low_bonus = 1.0 + 0.15 * (1.0 - (f_avg - self.fmin) / (self.fmax - self.fmin))
            sal = min(total_s * low_bonus / 2.0, 1.0)
            merged.append((float(f_avg), float(sal)))

        merged.sort(key=lambda x: x[1], reverse=True)
        return merged[:5]

    # ------------------------------------------------------------------
    # Tracking
    # ------------------------------------------------------------------

    def _track(self, frame_cands: list[list[tuple[float, float]]]) -> tuple[np.ndarray, np.ndarray]:
        n_frames = len(frame_cands)
        if n_frames == 0:
            return np.array([]), np.array([])

        states = []
        for cands in frame_cands:
            st = cands + [(0.0, self.voicing_threshold * 0.4)]
            states.append(st)

        n_max = max(len(s) for s in states)
        INF = 1e9
        cost = np.full((n_frames, n_max), INF)
        back = np.full((n_frames, n_max), -1, dtype=np.int32)

        for k, (f, s) in enumerate(states[0]):
            cost[0, k] = -np.log(s + 1e-6)

        for t in range(1, n_frames):
            for k, (f_k, s_k) in enumerate(states[t]):
                best_c, best_p = INF, -1
                for p, (f_p, s_p) in enumerate(states[t - 1]):
                    if f_k == 0 and f_p == 0:
                        trans = 0.03
                    elif f_k == 0 or f_p == 0:
                        trans = 0.45
                    else:
                        ratio = f_k / f_p
                        cents = 1200 * abs(np.log2(ratio))
                        octave_pen = 0.0
                        if 1.8 < ratio < 2.2 or 0.45 < ratio < 0.55:
                            octave_pen = self.octave_cost * 2.0
                        elif 2.7 < ratio < 3.3 or 0.30 < ratio < 0.37:
                            octave_pen = self.octave_cost * 1.5
                        trans = self.jump_cost * (cents / 80.0) + octave_pen
                    c = cost[t - 1, p] + trans - np.log(s_k + 1e-6)
                    if c < best_c:
                        best_c, best_p = c, p
                cost[t, k] = best_c
                back[t, k] = best_p

        f0_out = np.full(n_frames, np.nan)
        conf_out = np.zeros(n_frames)
        k = int(np.argmin(cost[-1, :len(states[-1])]))
        for t in range(n_frames - 1, -1, -1):
            f, s = states[t][k]
            if f > 0:
                f0_out[t] = f
                conf_out[t] = s
            k = back[t, k]
            if k < 0:
                break
        return f0_out, conf_out

    def _remove_octave_errors(self, f0: np.ndarray, conf: np.ndarray) -> np.ndarray:
        f0_out = f0.copy()
        valid = ~np.isnan(f0)
        if np.sum(valid) < 5:
            return f0_out

        # глобальная медиана как якорь
        global_med = float(np.nanmedian(f0))
        # сглаженная локальная медиана
        med = median_smooth(np.nan_to_num(f0, nan=global_med), kernel=11)

        for i in range(len(f0)):
            if np.isnan(f0[i]):
                continue
            ref = med[i] if med[i] >= self.fmin else global_med
            ratio = f0[i] / ref
            # жёсткая коррекция октав относительно локальной/глобальной медианы
            if 1.6 < ratio < 2.5:
                f0_out[i] = f0[i] / 2.0
            elif 2.5 < ratio < 3.6:
                f0_out[i] = f0[i] / 3.0
            elif 0.35 < ratio < 0.62:
                f0_out[i] = f0[i] * 2.0
            # дополнительно: если всё ещё далеко от global_med — ещё раз
            r2 = f0_out[i] / global_med
            if 1.7 < r2 < 2.4:
                f0_out[i] = f0_out[i] / 2.0
            elif 2.6 < r2 < 3.5:
                f0_out[i] = f0_out[i] / 3.0
        return f0_out

    def estimate(self, x: np.ndarray, sr: Optional[int] = None) -> F0Result:
        if sr is not None and sr != self.sr:
            from scipy.signal import resample
            x = resample(x, int(len(x) * self.sr / sr))

        if self.prefilter == "preemph":
            x = preemphasis(x, 0.97)
        elif self.prefilter == "lp":
            from scipy.signal import butter, sosfiltfilt
            sos = butter(4, [40/(self.sr/2), 1200/(self.sr/2)], btype="band", output="sos"); x = sosfiltfilt(sos, x)
        frames = frame_signal(x, self.frame_len, self.hop, window="hann")
        n_frames = len(frames)
        times = (np.arange(n_frames) * self.hop + self.frame_len // 2) / self.sr

        frame_cands = []
        # все FFT-части считаем сразу для всех кадров (одна автокорреляция на YIN и NAC, кепстр пакетом)
        M = frames - frames.mean(axis=1, keepdims=True); nfr = M.shape[1]
        ACF = irfft(np.abs(rfft(M, n=1 << (nfr * 2 - 1).bit_length(), axis=1)) ** 2, n=1 << (nfr * 2 - 1).bit_length(), axis=1)[:, :nfr]
        CS = np.concatenate([np.zeros((len(M), 1)), np.cumsum(M * M, axis=1)], axis=1)
        CEP = irfft(safe_log(np.abs(rfft(M, n=nfr, axis=1))), n=nfr, axis=1)
        for i, fr in enumerate(frames):
            yin = self._yin_candidates(fr, pre=(ACF[i], CS[i]))
            nac = self._nac_candidates(fr, ac=ACF[i])
            cep = self._cepstrum_candidates(fr, cep=CEP[i])
            merged = self._merge_candidates(yin, nac, cep)
            frame_cands.append(merged)

        f0, conf = self._track(frame_cands)
        f0 = self._remove_octave_errors(f0, conf)

        # энергетический гейт: кадры заметно тише пика речи не могут быть вокализованы
        e = np.sqrt(np.mean(frames ** 2, axis=1) + 1e-20)
        e_db = 20 * np.log10(e / (np.percentile(e, 95) + 1e-20) + 1e-20)
        loud = e_db > self.gate_db
        # шумовой пол: кадры не выше пола + margin не могут быть вокализованы (только если в файле есть заметно более тихие кадры)
        if self.floor_margin_db > 0 and len(e) >= 20:
            ea = 20 * np.log10(e); fl = np.percentile(ea, 10)
            if fl < np.median(ea) - 6.0: loud = loud & (ea > fl + self.floor_margin_db)
        voiced = (~np.isnan(f0)) & (conf >= self.voicing_threshold) & loud
        f0[~voiced] = np.nan
        conf[~voiced] = 0.0

        return F0Result(times=times, f0=f0, confidence=conf, voiced=voiced)
