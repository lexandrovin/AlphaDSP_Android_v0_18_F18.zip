# Форманты F1..F18 (нужны F6..F18). Для F7+ нужна частота >= ~40 кГц: F18 ~ 17.5 кГц. На 16 кГц надёжны только F1..F8.
from __future__ import annotations
import numpy as np
from scipy.linalg import solve_toeplitz
from scipy.stats import trim_mean
from numpy.lib.stride_tricks import sliding_window_view as _swv
def _lpc(w, p): r = np.correlate(w, w, "full")[len(w) - 1:len(w) + p]; return np.r_[1.0, -solve_toeplitz(r[:p] + 1e-9 * r[0] + 1e-12, r[1:p + 1])] if r[0] > 1e-12 else None
def _frame(w, sr, nf, bwmax): a = _lpc(w * np.hanning(len(w)), 2 * nf + 2); r = np.roots(a) if a is not None else np.array([]); r = r[np.imag(r) > 1e-6]; f = np.angle(r) * sr / (2 * np.pi); bw = -np.log(np.abs(r) + 1e-15) * sr / np.pi; m = (f > 90) & (bw < bwmax); o = np.argsort(f[m])[:nf]; return f[m][o], bw[m][o]
def high_formants(x, sr, n_formants=18, frame_ms=25.0, hop_ms=10.0, preemph_hz=50.0, bwmax=1000.0):
 x = np.asarray(x, dtype=np.float64); x = x - x.mean(); c = np.exp(-2 * np.pi * preemph_hz / sr) if preemph_hz else 0.0; x = np.r_[x[0], x[1:] - c * x[:-1]]; fl, hop = int(sr * frame_ms / 1000), int(sr * hop_ms / 1000); W = _swv(np.pad(x, (0, max(0, fl - len(x)))), fl)[::hop]; rms = np.sqrt((W ** 2).mean(1)); W = W[rms > max(1e-6, 0.05 * rms.max())]; F = np.full((len(W), n_formants), np.nan); BW = F.copy()
 for i, w in enumerate(W): f, b = _frame(w, sr, n_formants, bwmax); F[i, :len(f)] = f; BW[i, :len(b)] = b
 st = lambda v: (float(trim_mean(v, 0.1)), float(np.std(v))) if (~np.isnan(v)).sum() >= 5 else (float("nan"), float("nan")); S = [st(F[:, j][~np.isnan(F[:, j])]) for j in range(n_formants)]
 return {"F": F, "bandwidths": BW, "means": {f"F{j + 1}_mean": S[j][0] for j in range(n_formants)}, "stds": {f"F{j + 1}_std": S[j][1] for j in range(n_formants)}}
