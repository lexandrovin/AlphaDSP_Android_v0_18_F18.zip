"""
AlphaDSP · Formant estimation via adaptive LPC + tracking (v0.2)

Исправления:
- Менее агрессивный отбор корней (BW до 1000 Hz)
- Стабильный порядок по умолчанию
- Трекинг через nearest-neighbour с жёстким cost
- Заполнение пропусков линейной интерполяцией на коротких дырах
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from alpha_dsp.utils.signal import frame_signal, preemphasis


@dataclass
class FormantTrack:
    times: np.ndarray
    F: np.ndarray
    bandwidths: np.ndarray
    confidence: np.ndarray


@dataclass
class FormantSummary:
    tracks: FormantTrack
    means: dict[str, float]
    stds: dict[str, float]
    stability: dict[str, float]


class AdaptiveLPCFormants:
    def __init__(
        self,
        sr: int = 16000,
        n_formants: int = 5,
        frame_ms: float = 25.0,
        hop_ms: float = 10.0,
        preemph: float = 0.97,
        fmax: float = 5500.0,
    ):
        self.sr = sr
        self.n_formants = n_formants
        self.frame_len = int(sr * frame_ms / 1000)
        self.hop = int(sr * hop_ms / 1000)
        self.preemph = preemph
        self.fmax = fmax
        self.base_order = max(12, int(sr / 1000) + 4)

    def _lpc_burg(self, frame: np.ndarray, order: int) -> np.ndarray:
        n = len(frame)
        if n <= order + 2:
            return np.array([1.0] + [0.0] * order)

        a = np.zeros(order + 1)
        a[0] = 1.0
        ef = frame.astype(np.float64).copy()
        eb = frame.astype(np.float64).copy()

        for m in range(1, order + 1):
            num = -2.0 * np.dot(ef[m:n], eb[m - 1:n - 1])
            den = np.dot(ef[m:n], ef[m:n]) + np.dot(eb[m - 1:n - 1], eb[m - 1:n - 1])
            k = 0.0 if abs(den) < 1e-14 else np.clip(num / den, -0.995, 0.995)

            a_prev = a.copy()
            for i in range(1, m):
                a[i] = a_prev[i] + k * a_prev[m - i]
            a[m] = k

            ef_old = ef.copy()
            ef[m:n] = ef_old[m:n] + k * eb[m - 1:n - 1]
            eb[m:n] = eb[m - 1:n - 1] + k * ef_old[m:n]

        return a

    def _roots_to_formants(self, a: np.ndarray) -> list[tuple[float, float]]:
        roots = np.roots(a)
        formants = []
        for r in roots:
            if np.imag(r) <= 1e-10:
                continue
            ang = np.angle(r)
            freq = ang * self.sr / (2 * np.pi)
            if freq < 80 or freq > self.fmax:
                continue
            bw = -0.5 * (self.sr / np.pi) * np.log(np.abs(r) + 1e-15)
            if bw < 5 or bw > 1200:
                continue
            formants.append((float(freq), float(bw)))
        formants.sort(key=lambda x: x[0])
        return formants

    def _track_formants(
        self,
        all_cands: list[list[tuple[float, float]]],
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        n = len(all_cands)
        F = np.full((n, self.n_formants), np.nan)
        BW = np.full((n, self.n_formants), np.nan)
        conf = np.zeros((n, self.n_formants))

        start = 0
        for i, cands in enumerate(all_cands):
            if len(cands) >= 2:
                for j, (f, bw) in enumerate(cands[:self.n_formants]):
                    F[i, j] = f
                    BW[i, j] = bw
                    conf[i, j] = float(np.clip(1.0 - bw / 600.0, 0.15, 1.0))
                start = i
                break

        for i in range(start + 1, n):
            cands = all_cands[i]
            if not cands:
                continue
            prev = F[i - 1]
            used = set()
            for j in range(self.n_formants):
                if np.isnan(prev[j]):
                    best_i, best_d = -1, 1e9
                    expected = [500, 1500, 2500, 3500, 4500][j]
                    for k, (f, bw) in enumerate(cands):
                        if k in used:
                            continue
                        d = abs(f - expected)
                        if d < best_d:
                            best_d, best_i = d, k
                    if best_i >= 0 and best_d < 800:
                        f, bw = cands[best_i]
                        F[i, j] = f
                        BW[i, j] = bw
                        conf[i, j] = float(np.clip(1.0 - bw / 600.0, 0.15, 1.0))
                        used.add(best_i)
                    continue

                best_i, best_d = -1, 1e9
                for k, (f, bw) in enumerate(cands):
                    if k in used:
                        continue
                    d = abs(f - prev[j])
                    if d < best_d:
                        best_d, best_i = d, k
                if best_i >= 0 and best_d < 500:
                    f, bw = cands[best_i]
                    F[i, j] = f
                    BW[i, j] = bw
                    conf[i, j] = float(np.clip(1.0 - bw / 600.0, 0.15, 1.0))
                    used.add(best_i)

        for j in range(self.n_formants):
            col = F[:, j]
            for i in range(1, n - 1):
                if np.isnan(col[i]) and not np.isnan(col[i - 1]) and not np.isnan(col[i + 1]):
                    F[i, j] = 0.5 * (col[i - 1] + col[i + 1])
                    BW[i, j] = 0.5 * (BW[i - 1, j] + BW[i + 1, j])
                    conf[i, j] = 0.4

        return F, BW, conf

    def estimate(self, x: np.ndarray) -> FormantSummary:
        x = preemphasis(x, self.preemph)
        frames = frame_signal(x, self.frame_len, self.hop, window="hann")
        n_frames = len(frames)
        times = (np.arange(n_frames) * self.hop + self.frame_len // 2) / self.sr

        all_cands = []
        for fr in frames:
            rms = np.sqrt(np.mean(fr ** 2))
            if rms < 1e-4:
                all_cands.append([])
                continue
            a = self._lpc_burg(fr, self.base_order)
            cands = self._roots_to_formants(a)
            all_cands.append(cands)

        F, BW, conf = self._track_formants(all_cands)

        means, stds, stability = {}, {}, {}
        for j in range(self.n_formants):
            col = F[:, j]
            valid = col[~np.isnan(col)]
            key = f"F{j + 1}"
            if len(valid) >= 5:
                means[f"{key}_mean"] = float(np.mean(valid))
                stds[f"{key}_std"] = float(np.std(valid))
                stability[key] = float(np.clip(1.0 - np.std(valid) / (np.mean(valid) + 1e-6), 0, 1))
            else:
                means[f"{key}_mean"] = float("nan")
                stds[f"{key}_std"] = float("nan")
                stability[key] = 0.0

        return FormantSummary(
            tracks=FormantTrack(times=times, F=F, bandwidths=BW, confidence=conf),
            means=means, stds=stds, stability=stability,
        )
