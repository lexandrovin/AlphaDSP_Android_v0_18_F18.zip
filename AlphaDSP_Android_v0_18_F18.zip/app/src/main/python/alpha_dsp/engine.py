"""
AlphaDSP · главный движок Слоя B

Собственная реализация, ориентированная на превосходство над
Praat + OpenSMILE + Librosa.

Выход совместим с форматом отчёта §5 спецификации ИИ-Альфа.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np
from scipy.io import wavfile as _wf
from scipy.signal import resample_poly as _rp
from math import gcd as _gcd

from alpha_dsp.core.f0 import HybridF0, F0Result
from alpha_dsp.core.periods import PeriodDetector, PerturbationAnalyzer, PerturbationResult
from alpha_dsp.core.formants import FormantSummary
from alpha_dsp.core.formants2 import RobustFormants
from alpha_dsp.core.formants_high import high_formants
from alpha_dsp.core.cpps import cpps as cpps_fn
from alpha_dsp.core.hnr import HarmonicityAnalyzer, HNRResult
from alpha_dsp.core.temporal import TemporalAnalyzer, TemporalResult


@dataclass
class Measurement:
    value: Any
    unit: str
    method: str
    uncertainty: Optional[float] = None


@dataclass
class FeatureItem:
    layer: str = "B"
    parameter: str = ""
    measurement: dict = field(default_factory=dict)
    speaker_id: str = "spk_1"
    time_interval: Optional[list[float]] = None
    hypothesis: Optional[str] = None
    confidence: str = "UNDET"
    probability: Optional[float] = None
    evidence_ids: list[str] = field(default_factory=list)
    uncertainty_ref: str = "E1:E2"
    limitations: list[str] = field(default_factory=list)
    recommended_specialist: Optional[str] = None
    urgency: str = "routine"
    verdict_produced: bool = False


def _read_wav(p): sr, d = _wf.read(str(p)); d = d.astype(np.float64) / (float(np.iinfo(d.dtype).max) if np.issubdtype(d.dtype, np.integer) else 1.0); return (d.mean(1) if d.ndim > 1 else d), int(sr)


class AlphaDSP:
    """
    Полный пайплайн Слоя B.
    """

    def __init__(self, sr: int = 16000):
        self.sr = sr
        self.f0_tracker = HybridF0(sr=sr, fmax=600.0, prefilter="lp", gate_db=-18.0, voicing_threshold=0.5)
        self.period_detector = PeriodDetector(sr=sr)
        self.perturbation = PerturbationAnalyzer(sr=sr)
        self.formants = RobustFormants(sr=sr)
        self.hnr = HarmonicityAnalyzer(sr=sr)
        self.temporal = TemporalAnalyzer(sr=sr)

    def load(self, path: str | Path) -> tuple[np.ndarray, int]:
        y, fsr = _read_wav(path)
        g = _gcd(self.sr, fsr)
        return (_rp(y, self.sr // g, fsr // g) if fsr != self.sr else y).astype(np.float64), self.sr

    def analyze(
        self,
        audio: str | Path | np.ndarray,
        speaker_id: str = "spk_1",
        evidence_prefix: str = "e",
    ) -> dict[str, Any]:
        if isinstance(audio, (str, Path)):
            y, sr = self.load(audio)
            source = str(audio)
        else:
            y = np.asarray(audio, dtype=np.float64)
            sr = self.sr
            source = "array"

        duration = len(y) / sr

        # --- 1. F0 ---
        f0_res: F0Result = self.f0_tracker.estimate(y)

        # --- 2. Periods + Jitter/Shimmer ---
        periods = self.period_detector.detect(y, f0_res)
        pert: PerturbationResult = self.perturbation.analyze(periods)

        # --- 3. Formants ---
        form: FormantSummary = self.formants.estimate(y)
        # --- 3b. F6..F18: файл читается в родной частоте (F9+ нужны >= ~40 кГц); для массива — на sr движка ---
        hy, hsr = _read_wav(audio) if isinstance(audio, (str, Path)) else (y, sr)
        hf = high_formants(hy, hsr, n_formants=min(18, int(hsr // 2000)))
        hn = hf["F"].shape[1]

        # --- 4. HNR / CPPS ---
        hnr_res: HNRResult = self.hnr.analyze(y)
        _c = cpps_fn(y, sr)
        if _c is not None: hnr_res.cpps = _c

        # --- 5. Temporal (pauses + VOT) ---
        temp: TemporalResult = self.temporal.analyze(
            y, f0_times=f0_res.times, f0_voiced=f0_res.voiced
        )

        # --- Сводка ---
        f0_valid = f0_res.f0[~np.isnan(f0_res.f0)]
        summary = {
            "source": source,
            "duration_s": duration,
            "sample_rate": sr,
            "speaker_id": speaker_id,
            # F0
            "f0_mean_hz": float(np.mean(f0_valid)) if len(f0_valid) else None,
            "f0_std_hz": float(np.std(f0_valid)) if len(f0_valid) else None,
            "f0_min_hz": float(np.min(f0_valid)) if len(f0_valid) else None,
            "f0_max_hz": float(np.max(f0_valid)) if len(f0_valid) else None,
            "f0_range_hz": float(np.ptp(f0_valid)) if len(f0_valid) else None,
            "f0_voiced_fraction": float(np.mean(f0_res.voiced)),
            # Perturbation
            "jitter_local": pert.jitter_local,
            "jitter_rap": pert.jitter_rap,
            "jitter_ppq5": pert.jitter_ppq5,
            "shimmer_local": pert.shimmer_local,
            "shimmer_apq3": pert.shimmer_apq3,
            "shimmer_apq5": pert.shimmer_apq5,
            "n_periods": pert.n_periods,
            "perturbation_reliability": pert.reliability,
            "perturbation_reason": pert.reliability_reason,
            # HNR / CPPS
            "hnr_mean_db": hnr_res.hnr_mean,
            "hnr_std_db": hnr_res.hnr_std,
            "cpps_db": hnr_res.cpps,
            "hnr_reliability": hnr_res.reliability,
            # Formants
            **form.means,
            **form.stds,
            **{k: v for k, v in hf["means"].items() if int(k[1:].split("_")[0]) > 5},
            **{k: v for k, v in hf["stds"].items() if int(k[1:].split("_")[0]) > 5},
            "formant_stability": form.stability,
            # Temporal
            "n_pauses": temp.n_pauses,
            "total_pause_s": temp.total_pause_s,
            "speech_duration_s": temp.speech_duration_s,
            "pause_ratio": temp.pause_ratio,
            "n_vot_events": len(temp.vot_events),
            "vot_events": [
                {"burst": e.burst_time, "onset": e.voicing_onset,
                 "vot_ms": e.vot_ms, "place": e.place_hint}
                for e in temp.vot_events
            ],
        }

        # --- FeatureItems для §5 ---
        items: list[FeatureItem] = []
        eid = 1

        def add(
            param: str,
            value: Any,
            unit: str,
            method: str,
            conf: str = "MED",
            hyp: Optional[str] = None,
            unc: Optional[float] = None,
            specialist: Optional[str] = None,
            lim: Optional[list] = None,
        ):
            nonlocal eid
            if value is None or (isinstance(value, float) and np.isnan(value)):
                return
            evidence = f"{evidence_prefix}_{eid:04d}"
            eid += 1
            items.append(FeatureItem(
                parameter=param,
                measurement={
                    "value": value,
                    "unit": unit,
                    "method": method,
                    "uncertainty": unc,
                },
                speaker_id=speaker_id,
                time_interval=[0.0, duration],
                hypothesis=hyp,
                confidence=conf,
                probability={"HIGH": 0.90, "MED": 0.72, "LOW": 0.50, "UNDET": None}.get(conf),
                evidence_ids=[evidence],
                uncertainty_ref="E1:E2",
                limitations=lim or ["no baseline", "single speaker assumed"],
                recommended_specialist=specialist,
            ))

        # F0
        add("f0_mean", summary["f0_mean_hz"], "Hz", "alpha_hybrid_f0",
            conf="HIGH" if summary["f0_voiced_fraction"] > 0.5 else "MED")
        add("f0_range", summary["f0_range_hz"], "Hz", "alpha_hybrid_f0")

        # Jitter / Shimmer
        j_conf = pert.reliability if pert.reliability != "UNDET" else "UNDET"
        add("jitter_local", pert.jitter_local, "ratio", "alpha_period_matching",
            conf=j_conf,
            hyp="признаки, совместимые с нестабильностью фонации"
                if (pert.jitter_local or 0) > 0.01 else None,
            specialist="фониатр")
        add("jitter_rap", pert.jitter_rap, "ratio", "alpha_period_matching", conf=j_conf)
        add("shimmer_local", pert.shimmer_local, "ratio", "alpha_period_matching", conf=j_conf)
        add("shimmer_apq5", pert.shimmer_apq5, "ratio", "alpha_period_matching", conf=j_conf)

        # HNR / CPPS
        add("hnr_mean", hnr_res.hnr_mean, "dB", "alpha_ac_hnr", conf=hnr_res.reliability)
        add("cpps", hnr_res.cpps, "dB", "alpha_cpps", conf=hnr_res.reliability)

        # Formants
        for i in range(1, 6):
            add(f"F{i}_mean", form.means.get(f"F{i}_mean"), "Hz", "alpha_adaptive_lpc")
            add(f"F{i}_std", form.stds.get(f"F{i}_std"), "Hz", "alpha_adaptive_lpc")

        for i in range(6, hn + 1):
            add(f"F{i}_mean", hf["means"].get(f"F{i}_mean"), "Hz", "alpha_high_lpc")
            add(f"F{i}_std", hf["stds"].get(f"F{i}_std"), "Hz", "alpha_high_lpc")

        # Temporal
        add("n_pauses", float(temp.n_pauses), "count", "alpha_multi_vad")
        add("pause_ratio", temp.pause_ratio, "ratio", "alpha_multi_vad")
        if temp.vot_events:
            mean_vot = float(np.mean([e.vot_ms for e in temp.vot_events]))
            add("vot_mean_ms", mean_vot, "ms", "alpha_burst_voicing")

        report = {
            "meta": {
                "session_id": f"alpha_{Path(source).stem if source != 'array' else 'mem'}",
                "doc_version": "1.2",
                "model_version": "alpha_dsp_v0.5",
                "mode": "R1",
                "quality_gate_passed": duration >= 3.0,
                "fallback_applied": [],
            },
            "speakers": [{
                "speaker_id": speaker_id,
                "segments": [[0.0, duration]],
                "attribution_confidence": 1.0,
            }],
            "items": [asdict(it) for it in items],
            "summary": summary,
            "global_uncertainty": {
                "E_items": [],
                "unresolved": [],
                "perturbation_note": pert.reliability_reason,
            },
        }
        return report


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    import argparse
    parser = argparse.ArgumentParser(description="AlphaDSP — собственный движок Слоя B")
    parser.add_argument("audio", help="Путь к аудиофайлу")
    parser.add_argument("--out-json", default=None)
    parser.add_argument("--out-csv", default=None)
    parser.add_argument("--speaker", default="spk_1")
    args = parser.parse_args()

    engine = AlphaDSP()
    report = engine.analyze(args.audio, speaker_id=args.speaker)

    print("\n=== AlphaDSP Layer B summary ===")
    s = report["summary"]
    for k in [
        "f0_mean_hz", "f0_range_hz", "f0_voiced_fraction",
        "jitter_local", "jitter_rap", "shimmer_local",
        "hnr_mean_db", "cpps_db",
        "F1_mean", "F2_mean", "F3_mean",
        "n_pauses", "pause_ratio", "n_vot_events",
        "perturbation_reliability",
    ]:
        print(f"  {k:25s}: {s.get(k)}")

    print(f"\n  items in report: {len(report['items'])}")

    if args.out_json:
        with open(args.out_json, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2, default=str)
        print(f"  JSON → {args.out_json}")

    if args.out_csv:
        import pandas as pd
        flat = {k: v for k, v in s.items() if not isinstance(v, (list, dict))}
        pd.DataFrame([flat]).to_csv(args.out_csv, index=False)
        print(f"  CSV  → {args.out_csv}")


if __name__ == "__main__":
    main()
