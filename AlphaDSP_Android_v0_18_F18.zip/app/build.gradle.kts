plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("com.chaquo.python") }
android {
namespace = "ru.alphadsp"
compileSdk = 34
defaultConfig { applicationId = "ru.alphadsp.demo"; minSdk = 24; targetSdk = 34; versionCode = 18; versionName = "0.18-F18"; ndk { abiFilters += listOf("arm64-v8a", "x86_64") } }
compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
kotlinOptions { jvmTarget = "17" }
}
chaquopy { defaultConfig { version = "3.10"; buildPython("python3"); pip { install("numpy==1.23.3"); install("scipy==1.8.1"); options("--ignore-requires-python") } } }
dependencies { implementation("androidx.activity:activity-ktx:1.9.0") }
